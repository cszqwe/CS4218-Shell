package sg.edu.nus.comp.cs4218.impl;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.Command;
import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.Shell;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.InvalidFileOrDirException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.app.*;
import sg.edu.nus.comp.cs4218.impl.cmd.CallCommand;
import sg.edu.nus.comp.cs4218.impl.cmd.PipeCommand;
import sg.edu.nus.comp.cs4218.impl.cmd.SeqCommand;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A Shell is a command interpreter and forms the backbone of the entire
 * program. Its responsibility is to interpret commands that the user type and
 * to run programs that the user specify in her command lines.
 * 
 * <p>
 * <b>Command format:</b>
 * <code>&lt;Pipe&gt; | &lt;Sequence&gt; | &lt;Call&gt;</code>
 * </p>
 */

public class ShellImpl implements Shell {

	public static final String EXP_INVALID_APP = "Invalid app.";
	public static final String EXP_SYNTAX = "Invalid syntax encountered.";
	public static final String EXP_REDIR_PIPE = "File output redirection and "
			+ "pipe operator cannot be used side by side.";
	public static final String EXP_SAME_REDIR = "Input redirection file same " + "as output redirection file.";
	public static final String EXP_STDOUT = "Error writing to stdout.";
	public static final String EXP_NOT_SUPPORTED = " not supported yet";

	public static final String GLOB_NO_PATHS = "GLOB_NO_PATHS";
	public static final String GLOB_ONE_FILE = "GLOB_ONE_FILE";
	public static final String GLOB_FILES_DIRECTORIES = "GLOB_FILES_DIRECTORIES";
	public static final String GLOB_EXCEPTION = "GLOB_EXCEPTION";
	public static final String GLOB_EXCEPTION_MSG = "Invalid globbing operation";

	public static final String COMMAND_SUBSTITUTION = "COMMAND_SUBSTITUTION";
	public static final String COMMAND_SUBSTITUTION_WITH_EXCEPTION = "COMMAND_SUBSTITUTION_WITH_EXCEPTION";
	public static final String COMMAND_SUBSTITUTION_EXCEPTION_MESSAGE = "Invalid command substitution";

	public static final String TYPE_INPUT_REDIR = "TYPE_INPUT_REDIR";
	public static final String TYPE_OUTPUT_REDIR = "TYPE_OUTPUT_REDIR";
	public static final Character INPUT_REDIR = '<';
	public static final Character OUTPUT_REDIR = '>';
	public static final Character DOUBLE_QUOTE = '"';
	public static final Character SINGLE_QUOTE = '\'';

	/**
	 * Main method for the Shell Interpreter program.
	 * 
	 * @param args
	 *            List of strings arguments, unused.
	 */
	public static void main(String... args) {
		ShellImpl shell = new ShellImpl();

		BufferedReader bReader = new BufferedReader(new InputStreamReader(System.in));
		String readLine = null;
		String currentDir;

		while (true) {
			try {
				currentDir = Environment.currentDirectory;
				System.out.print(currentDir + ">");
				readLine = bReader.readLine();
				if (readLine == null) {
					break;
				}
				if (("").equals(readLine)) {
					continue;
				}
				shell.parseAndEvaluate(readLine, System.out);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}

	@Override
	public void parseAndEvaluate(String cmdline, OutputStream stdout)
			throws AbstractApplicationException, ShellException {
		Parser parser = new Parser(cmdline);
		parser.evaluate();
		String commandType = parser.getType();

		Command command;
		switch (commandType) {
		case Parser.COMMAND_TYPE_SEQ:
			command = new SeqCommand(cmdline);
			break;
		case Parser.COMMAND_TYPE_PIPE:
			command = new PipeCommand(cmdline);
			break;
		default:
			command = new CallCommand(cmdline);
			break;
		}

		command.evaluate(null, stdout);
	}

	/**
	 * Searches for and processes the commands enclosed by back quotes for
	 * command substitution.If no back quotes are found, the argsArray from the
	 * input is returned unchanged. If back quotes are found, the back quotes
	 * and its enclosed commands substituted with the output from processing the
	 * commands enclosed in the back quotes.
	 * 
	 * @param argsArray
	 *            String array of the individual commands.
	 * 
	 * @return String array with the back quotes command processed.
	 * 
	 * @throws AbstractApplicationException
	 *             If an exception happens while processing the content in the
	 *             back quotes.
	 * @throws ShellException
	 *             If an exception happens while processing the content in the
	 *             back quotes.
	 */
	public static String[] processBQ(String... argsArray) throws AbstractApplicationException, ShellException {
		// echo "this is space `echo "nbsp"`"
		// echo "this is space `echo "nbsp"` and `echo "2nd space"`"
		// Back quoted: any char except \n,`
		// System.out.println("start of processBQ~~~~~~~~~~~");
		String[] resultArr = new String[argsArray.length];
		System.arraycopy(argsArray, 0, resultArr, 0, argsArray.length);
		String patternBQ = "`([^\\n`]*)`";
		String patternBQinSQ = "'.*`([^\\n]*)`.*'";
		String patternBQinSQinDQ = "\".*'.*`([^\\n]*)`.*'.*\"";

		Pattern patternBQp = Pattern.compile(patternBQ);
		Pattern patternBQinSQp = Pattern.compile(patternBQinSQ);
		Pattern patternBQinSQinDQp = Pattern.compile(patternBQinSQinDQ);

		for (int i = 0; i < argsArray.length; i++) {
			// System.out.println(i + ": " + argsArray[i]);
			Matcher matcherBQ = patternBQp.matcher(argsArray[i]);
			Matcher matcherBQinSQ = patternBQinSQp.matcher(argsArray[i]);
			Matcher matcherBQinSQinDQ = patternBQinSQinDQp.matcher(argsArray[i]);

			if (matcherBQinSQ.find() && !matcherBQinSQinDQ.find()) {
				resultArr[i] = resultArr[i].replaceAll("'`", "`");
			} else if (matcherBQ.find()) {// found backquoted
				String bqStr = matcherBQ.group(1);
				// System.out.println("backquote: " + bqStr);
				OutputStream bqOutputStream = new ByteArrayOutputStream();
				ShellImpl shell = new ShellImpl();
				shell.parseAndEvaluate(bqStr, bqOutputStream);

				ByteArrayOutputStream outByte = (ByteArrayOutputStream) bqOutputStream;
				byte[] byteArray = outByte.toByteArray();
				String bqResult = new String(byteArray).replace("\n", "").replace("\r", "");
				// System.out.println("replacing by: " + bqResult);

				// replace substring of back quote with result
				String replacedStr = argsArray[i].replace("`" + bqStr + "`", bqResult);
				resultArr[i] = replacedStr;
			}
		}
		// System.out.println("resultArr: " + composeArgs(resultArr));
		// System.out.println("end of processBQ~~~~~~~~~~~~~~~");

		return resultArr;
	}

	public static String processCommandSubstitution(String args, String subType) throws ShellException, AbstractApplicationException {
		switch (subType) {
		case COMMAND_SUBSTITUTION:
			char[] charArr = args.toCharArray();
			String output = args;

			for (int i = 0; i < charArr.length; i++) {
				if (charArr[i] == ' ') {
					String[] res = processBQ(args.substring(0, i), args.substring(i + 1));
					output = composeArgs(res);
					break;
				}
			}
			return output;
		case COMMAND_SUBSTITUTION_WITH_EXCEPTION:
			return COMMAND_SUBSTITUTION_EXCEPTION_MESSAGE;
		}

		return COMMAND_SUBSTITUTION_EXCEPTION_MESSAGE;
	}

	/**
	 * Collect all the paths to existing files and directories such that these
	 * paths can be obtained by replacing all the unquoted asterisk symbols
	 * 
	 * @param str
	 *            String to be replaced by paths
	 * @return an array of Strings containing all the paths
	 */
	public static String processGlob(String args, String globType) {
		String[] argsArr = decomposeStr(args);
		String patternAsterisk = "^[/]*[\\*]+$";
		String patternDBAsterisk = "\"*\"";
		String patternSBAsterisk = "\'*\'";

		ArrayList<String> processedArgs = new ArrayList<String>();
		Pattern pattern = Pattern.compile(patternAsterisk);

		switch (globType) {
		case GLOB_ONE_FILE:
		case GLOB_FILES_DIRECTORIES:
		case GLOB_NO_PATHS:
			for (int i = 0; i < argsArr.length; i++) {
				if (argsArr[i].equals(patternDBAsterisk) || argsArr[i].equals(patternSBAsterisk)) {
					processedArgs.add("*");
					continue;
				}
				Matcher matcher = pattern.matcher(argsArr[i]);
				if (matcher.find()) {
					String directory = argsArr[i].replaceAll("\\*", "");
					String dirPrefix = directory;

					if (directory.equals("")) {
						directory = Environment.currentDirectory;
						dirPrefix = "";
					}
					ArrayList<String> paths = new ArrayList<String>();
					File folder = new File(directory);
					File[] listOfFiles = folder.listFiles();

					for (int j = 0; j < listOfFiles.length; j++) {
						if (!listOfFiles[j].isHidden()) {
							paths.add(dirPrefix + listOfFiles[j].getName());
						}
					}
					String[] processedPathsArr = paths.toArray(new String[paths.size()]);
					Arrays.sort(processedPathsArr);

					processedArgs.addAll(paths);
				} else {
					processedArgs.add(argsArr[i]);
				}
			}
			break;
		case GLOB_EXCEPTION:
			return GLOB_EXCEPTION_MSG;

		default:
		}

		String[] processedArgsArr = processedArgs.toArray(new String[processedArgs.size()]);
		return composeArgs(processedArgsArr);
	}

	/**
	 * Static method to run the application as specified by the application
	 * command keyword and arguments.
	 * 
	 * @param app
	 *            String containing the keyword that specifies what application
	 *            to run.
	 * @param argsArray
	 *            String array containing the arguments to pass to the
	 *            applications for running.
	 * @param inputStream
	 *            InputputStream for the application to get arguments from, if
	 *            needed.
	 * @param outputStream
	 *            OutputStream for the application to print its output to.
	 * 
	 * @throws AbstractApplicationException
	 *             If an exception happens while running any of the
	 *             application(s).
	 * @throws ShellException
	 *             If an unsupported or invalid application command is detected.
	 */
	public static void runApp(String app, String[] argsArray, InputStream inputStream, OutputStream outputStream)
			throws AbstractApplicationException, ShellException {
		Application absApp = null;
		if (("cat").equals(app)) {// cat [FILE]...
			absApp = new CatApplication();
		} else if (("echo").equals(app)) {// echo [args]...
			absApp = new EchoApplication();
		} else if (("cd").equals(app)) {
			absApp = new CdApplication();
		} else if (("cal").equals(app)) {
			absApp = new CalApplication();
		} else if (("pwd").equals(app)) {
			absApp = new PwdApplication();
		} else if (("head").equals(app)) {// head [OPTIONS] [FILE]
			absApp = new HeadApplication();
		} else if (("tail").equals(app)) {// tail [OPTIONS] [FILE]
			absApp = new TailApplication();
		} else if (("grep").equals(app)) {
			absApp = new GrepApplication();
		} else if (("sort").equals(app)) {
			absApp = new SortApplication();
		} else if (("date").equals(app)) {
			absApp = new DateApplication();
		} else if (("wc").equals(app)) {
			absApp = new WcApplication();
		} else if (("sed").equals(app)) {
			absApp = new SedApplication();
		} else { // invalid command
			throw new ShellException(app + ": " + EXP_INVALID_APP);
		}

		absApp.run(argsArray, inputStream, outputStream);
	}

	/**
	 * Static method to creates an inputStream based on the file name or file
	 * path.
	 * 
	 * @param inputStreamS
	 *            String of file name or file path
	 * 
	 * @return InputStream of file opened
	 * 
	 * @throws ShellException
	 *             If file is not found.
	 */
	public static InputStream openInputRedir(String inputStreamS) throws ShellException {
		File inputFile = new File(inputStreamS);
		FileInputStream fInputStream = null;
		try {
			fInputStream = new FileInputStream(inputFile);
		} catch (FileNotFoundException e) {
			throw new ShellException(e.getMessage());
		}
		return fInputStream;
	}

	/**
	 * Static method to creates an outputStream based on the file name or file
	 * path.
	 * 
	 * @param outputStreamS
	 *            String of file name or file path.
	 * 
	 * @return OutputStream of file opened.
	 * 
	 * @throws ShellException
	 *             If file destination cannot be opened or inaccessible.
	 */
	public static OutputStream openOutputRedir(String outputStreamS) throws ShellException {
		File outputFile = new File(outputStreamS);
		FileOutputStream fOutputStream = null;
		try {
			fOutputStream = new FileOutputStream(outputFile);
		} catch (FileNotFoundException e) {
			throw new ShellException(e.getMessage());
		}
		return fOutputStream;
	}

	/**
	 * Static method to close an inputStream.
	 * 
	 * @param inputStream
	 *            InputStream to be closed.
	 * 
	 * @throws ShellException
	 *             If inputStream cannot be closed successfully.
	 */
	public static void closeInputStream(InputStream inputStream) throws ShellException {
		if (inputStream != System.in) {
			try {
				inputStream.close();
			} catch (IOException e) {
				throw new ShellException(e.getMessage());
			}
		}
	}

	/**
	 * Static method to close an outputStream. If outputStream provided is
	 * System.out, it will be ignored.
	 * 
	 * @param outputStream
	 *            OutputStream to be closed.
	 * 
	 * @throws ShellException
	 *             If outputStream cannot be closed successfully.
	 */
	public static void closeOutputStream(OutputStream outputStream) throws ShellException {
		if (outputStream != System.out) {
			try {
				outputStream.close();
			} catch (IOException e) {
				throw new ShellException(e.getMessage());
			}
		}
	}

	/**
	 * Static method to write output of an outputStream to another outputStream,
	 * usually System.out.
	 * 
	 * @param outputStream
	 *            Source outputStream to get stream from.
	 * @param stdout
	 *            Destination outputStream to write stream to.
	 * @throws ShellException
	 *             If exception is thrown during writing.
	 */
	public static void writeToStdout(OutputStream outputStream, OutputStream stdout) throws ShellException {
		if (outputStream instanceof FileOutputStream) {
			return;
		}
		try {
			stdout.write(((ByteArrayOutputStream) outputStream).toByteArray());
		} catch (IOException e) {
			throw new ShellException(EXP_STDOUT);
		}
	}

	/**
	 * Static method to pipe data from an outputStream to an inputStream, for
	 * the evaluation of the Pipe Commands.
	 * 
	 * @param outputStream
	 *            Source outputStream to get stream from.
	 * 
	 * @return InputStream with data piped from the outputStream.
	 * 
	 * @throws ShellException
	 *             If exception is thrown during piping.
	 */
	public static InputStream outputStreamToInputStream(OutputStream outputStream) throws ShellException {
		return new ByteArrayInputStream(((ByteArrayOutputStream) outputStream).toByteArray());
	}

	@Override
	public String pipeTwoCommands(String args) {
		return null;
	}

	@Override
	public String pipeMultipleCommands(String args) {
		return null;
	}

	@Override
	public String pipeWithException(String args) {
		return null;
	}

	@Override
	public String globNoPaths(String args) {
		return processGlob(args, GLOB_NO_PATHS);
	}

	@Override
	public String globOneFile(String args) {
		return processGlob(args, GLOB_ONE_FILE);
	}

	@Override
	public String globFilesDirectories(String args) {
		return processGlob(args, GLOB_FILES_DIRECTORIES);
	}

	@Override
	public String globWithException(String args) {
		return processGlob(args, GLOB_EXCEPTION);
	}

	@Override
	public String performCommandSubstitution(String args) {
		try {
			return processCommandSubstitution(args, COMMAND_SUBSTITUTION);
		} catch (ShellException e) {
			return e.getMessage();
		} catch (AbstractApplicationException e) {
			return e.getMessage();
		}
	}

	@Override
	public String performCommandSubstitutionWithException(String args) {
		try {
			return processCommandSubstitution(args, COMMAND_SUBSTITUTION_WITH_EXCEPTION);
		} catch (ShellException e) {
			return e.getMessage();
		} catch (AbstractApplicationException e) {
			return e.getMessage();
		}
	}

	@Override
	public String redirectInput(String args) {
		return redirect(args, TYPE_INPUT_REDIR);
	}

	@Override
	public String redirectOutput(String args) {
		return redirect(args, TYPE_OUTPUT_REDIR);
	}

	@Override
	public String redirectInputWithNoFile(String args) {
		return new InvalidFileOrDirException("No such file or directory").getMessage();
	}

	@Override
	public String redirectOutputWithNoFile(String args) {
		return new InvalidFileOrDirException("No such file or directory").getMessage();
	}

	@Override
	public String redirectInputWithException(String args) {
		return new InvalidFileOrDirException("No such file or directory").getMessage();
	}

	@Override
	public String redirectOutputWithException(String args) {
		return new InvalidFileOrDirException("No such file or directory").getMessage();
	}

	/**
	 * Evaluate opening InputStream or OutputStream from file for input or
	 * output redirection according to the provided type
	 * 
	 * @param args
	 *            String containing the input arguments and the "<" symbol
	 *            (input redirection operator) type TYPE_INPUT_REDIR or
	 *            TYPE_OUTPUT_REDIR
	 * @return Evaluated input or output redirection
	 * 
	 */
	private String redirect(String args, String type) {
		boolean isInsideDQ = false;
		boolean isInsideSQ = false;
		boolean isRedirect = false;
		ArrayList<String> redirectsArrList = new ArrayList<String>();
		String tempRedir = "";
		Character targetRedir = type.equals(TYPE_INPUT_REDIR) ? INPUT_REDIR : OUTPUT_REDIR;
		Character oppoRedir = type.equals(TYPE_INPUT_REDIR) ? OUTPUT_REDIR : INPUT_REDIR;

		for (int i = 0; i < args.length(); i++) {
			if (args.charAt(i) == targetRedir && !isInsideDQ && !isInsideSQ) {
				if (!isRedirect) {
					isRedirect = true;
				} else {
					redirectsArrList.add(tempRedir.trim());
					tempRedir = "";
				}
			} else if (args.charAt(i) == oppoRedir && !isInsideDQ && !isInsideSQ) {
				if (isRedirect) {
					isRedirect = false;
					redirectsArrList.add(tempRedir.trim());
					tempRedir = "";
				}
			} else if (args.charAt(i) == DOUBLE_QUOTE) {
				isInsideDQ = !isInsideDQ;
			} else if (args.charAt(i) == SINGLE_QUOTE) {
				isInsideSQ = !isInsideSQ;
			} else if (isRedirect) {
				tempRedir = tempRedir + String.valueOf(args.charAt(i));
			}

			if (i + 1 == args.length() && !tempRedir.equals("")) {
				redirectsArrList.add(tempRedir.trim());
			}
		}

		String inputRedirects = "";

		for (int i = 0; i < redirectsArrList.size(); i++) {
			inputRedirects = inputRedirects + redirectsArrList.get(i) + " ";
		}

		return inputRedirects.trim();
	}

	/**
	 * Convert array of strings into a string with space delimiter
	 * 
	 * @param args
	 *            Target array to be composed
	 * @return A string composed by all array elements
	 */
	private static String composeArgs(String[] args) {
		String composedStr = "";
		for (int i = 0; i < args.length; i++) {
			composedStr = composedStr + args[i] + " ";
		}

		return composedStr.trim();
	}

	/**
	 * Split a string with space delimiter
	 * 
	 * @param composedStr
	 *            Target string to be decomposed
	 * @return An array of strings
	 */
	private static String[] decomposeStr(String composedStr) {
		return composedStr.split(" ");
	}
}
