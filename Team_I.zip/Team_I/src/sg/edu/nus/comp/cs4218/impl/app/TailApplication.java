package sg.edu.nus.comp.cs4218.impl.app;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.InvalidFileOrDirException;
import sg.edu.nus.comp.cs4218.exception.TailException;

import java.io.*;
import java.util.ArrayList;

public class TailApplication implements Application {
    @Override
    public void run(String[] args, InputStream stdin, OutputStream stdout) throws TailException {
        if (args == null) {
            throw new TailException("Null arguments");
        }

        if (stdout == null) {
            System.out.println("stdout null");
            throw new TailException("OutputStream not provided");
        }
        BufferedReader reader = null;

        // Print 10 lines if not specified
        int linesToPrint = 10;

        // Case when no file is specified: tail "test"

        // If stdin and filePath is provided, take filePath
        if (args.length == 0) {
            if (stdin == null) {
                throw new TailException("InputStream not provided");
            }
            reader = new BufferedReader(new InputStreamReader(stdin));
            printTail(linesToPrint, stdout, reader);
        }
        // Case when only file name is given: tail test.txt
        else if (args.length == 1) {
            printTailForFile(args[0], linesToPrint, stdout);
        }
        // Case when options and file is given
        else if (args.length == 2 || args.length == 3) { // case 3 or 4

            if (args[0].equals("-n")) {
                if(!args[1].matches("-?\\d+(\\.\\d+)?")) {
                    throw new TailException("illegal line count");
                }

                linesToPrint = Integer.parseInt(args[1]);

                if(linesToPrint < 0) {
                    throw new TailException("illegal line count");
                }

                if (args.length == 2) {
                    if (stdin == null) {
                        throw new TailException("InputStream not provided");
                    }

                    reader = new BufferedReader(
                            new InputStreamReader(stdin));

                    printTail(linesToPrint, stdout, reader);
                } else {
                    printTailForFile(args[2], linesToPrint, stdout);
                }
            } else {
                throw new TailException("Invalid options");
            }
        } else if (args.length > 3) {

            int optIndex = 0;
            for(int i = 0; i < args.length; i++) {
                if(args[i].equals("-n")) {
                    optIndex = i;
                }
            }
            // Case: tail -n 15 -n 15 -n
            if(optIndex + 1 == args.length) {
                throw new TailException("Invalid arguments");
            }

            // tail -n 15 -n 15 < test.txt
            if(optIndex + 2 == args.length) {
                if (stdin == null) {
                    throw new TailException("InputStream not provided");
                }

                linesToPrint = numberStrCheck(args[optIndex + 1]);

                reader = new BufferedReader(
                        new InputStreamReader(stdin));

                printTail(linesToPrint, stdout, reader);
            }

            // Case: tail -n 15 -n 5 test.txt
            else {
                linesToPrint = numberStrCheck(args[optIndex + 1]);

                printTailForFile(args[optIndex + 2], linesToPrint, stdout);
            }
        }
    }

    public int numberStrCheck(String num) throws TailException {
        if(!num.matches("-?\\d+(\\.\\d+)?")) {
            throw new TailException("illegal line count");
        }

        int intNum = Integer.parseInt(num);
        if(intNum < 0) {
            throw new TailException("illegal line count");
        }
        return intNum;
    }




    public void printTailForFile(String file, int linesToPrint, OutputStream stdout) throws TailException{
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(
                    Environment.checkFileOrDir(file)));
        } catch (IOException e) {
            throw new TailException("IOException");
        } catch (InvalidFileOrDirException e) {
            throw new TailException(e.getMessage());
        }

        printTail(linesToPrint, stdout, reader);
    }

    public void printTail(int linesToPrint, OutputStream stdout,
                           BufferedReader reader) throws TailException {

        String line;
        ArrayList<String> allLines = new ArrayList<>();

        try {
            while((line = reader.readLine()) != null) {
                allLines.add(line);
            }
            reader.close();

            int start = allLines.size() - linesToPrint;

            if(start < 0) {
                start = 0;
            }

            for(int i = start; i < allLines.size(); i++) {
                stdout.write(allLines.get(i).getBytes());
                stdout.write(System.getProperty("line.separator").getBytes());
            }

        } catch (IOException e) {
            throw new TailException("IOException");
        }
    }
}
