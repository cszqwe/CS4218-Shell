package sg.edu.nus.comp.cs4218.impl.app;

import sg.edu.nus.comp.cs4218.app.Cal;
import sg.edu.nus.comp.cs4218.exception.CalException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;

public class CalApplication implements Cal {
	private static final String SPACE = " ";
	private static final String LINE_SEPARATOR = "line.separator";
	String[] months = { "", // leave empty so that months[1] = "January"
			"January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
			"November", "December" };

	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws CalException {
		if (args == null) {
			throw new CalException("Null arguments");
		}

		if (stdout == null) {
			throw new CalException("OutputStream not provided");
		}

		Date date = new Date();
		@SuppressWarnings("deprecation")
		int currYear = date.getYear() + 1900;
		@SuppressWarnings("deprecation")
		int currMonth = date.getMonth() + 1;
		String finalStr = "";

		// Case for Sunday first
		// if year exists, we want to print the calendar for the year
		if (args.length == 1 && !args[0].equals("-m")) {
			if (checkValidYear(stringToInt(args[0]))) {
				finalStr = printCalForYear(args[0]);
			}
		}

		// if no month or year exists, print calendar for current month
		else if (args.length == 0) {
			String arg = currMonth + "," + currYear;
			finalStr = printCalForMonthYear(arg);
		}
		// else if the month and year exists, print calendar for the given month
		// and year
		else if (args.length == 2 && !args[0].equals("-m")) {
			if (checkValidMonth(stringToInt(args[0])) && checkValidYear(stringToInt(args[1]))) {
				String arg = args[0] + "," + args[1];
				finalStr = printCalForMonthYear(arg);
			}
		}

		// Case for Monday first
		// if year exists, we want to print the calendar for the year
		else if (args.length == 2 && args[0].equals("-m")) {
			// dayOfWeek algo requires year to be > 1752
			if (checkValidYear(stringToInt(args[1]))) {
				finalStr = printCalForYearMondayFirst(args[1]);
			}
		}
		// if no month or year exists, print calendar for current month
		else if (args[0].equals("-m") && args.length == 1) {
			String arg = currMonth + "," + currYear;
			finalStr = printCalForMonthYearMondayFirst(arg);
		}
		// else if the month and year exists, print calendar for the given month
		// and year
		else if (args[0].equals("-m") && args.length == 3
				&& (checkValidMonth(stringToInt(args[1])) || checkValidYear(stringToInt(args[2])))) {
			String arg = args[1] + "," + args[2];
			finalStr = printCalForMonthYearMondayFirst(arg);
		}

		try {
			stdout.write(finalStr.getBytes());
		} catch (IOException e) {
			throw new CalException("IOException");
		}

	}

	/**
	 * Converts a string input to an integer
	 * 
	 * @param val
	 * @return
	 */
	public int stringToInt(String val) throws CalException {
		if (!val.matches("-?\\d+(\\.\\d+)?")) {
			throw new CalException("illegal line count");
		}
		return Integer.parseInt(val);

	}

	/**
	 * Checks if the month is valid and throws an exception otherwise.
	 * 
	 * @param month
	 * @return
	 * @throws CalException
	 */
	public boolean checkValidMonth(int month) throws CalException {
		if (month > 12 || month < 1) {
			throw new CalException("Invalid month input");
		}
		return true;

	}

	/**
	 * Checks if year is valid and throws and exception otherwise. Year has to
	 * be > 1752.
	 * 
	 * @param year
	 * @return
	 * @throws CalException
	 */
	public boolean checkValidYear(int year) throws CalException {
		// dayOfWeek algo requires year to be > 1752
		if (year < 1752 || year > 9999) {
			throw new CalException("Invalid year input");
		}
		return true;
	}

	/**
	 * Returns a string that prints the calendar with monday first
	 * 
	 * @param args
	 *            String containing command and arguments
	 * @return
	 */
	@Override
	public String printCalWithMondayFirst(String args) {
		String[] argsSplit = args.split(",");
		String str = "";

		int month = Integer.parseInt(argsSplit[0]); // month
		int year = Integer.parseInt(argsSplit[1]); // year

		str += ("   " + months[month] + SPACE + year) + System.getProperty(LINE_SEPARATOR);
		str += ("Mo Tu We Th Fr Sa Su") + System.getProperty(LINE_SEPARATOR);

		ArrayList<ArrayList<String>> tempLoop = getCalArrayForMonth(month, dayOfWeek(month, 0, year), year);

		for (int a = 0; a < tempLoop.size(); a++) {
			for (int j = 0; j < tempLoop.get(a).size(); j++) {
				str += tempLoop.get(a).get(j);
			}
			str += System.getProperty(LINE_SEPARATOR);
		}
		return str;
	}

	/**
	 * Returns the day of the week given the date, month, year
	 * 
	 * @param month
	 *            Month
	 * @param day
	 *            Day
	 * @param year
	 *            Year
	 * @return
	 */
	public static int dayOfWeek(int month, int day,
			int year) /* 1 <= m <= 12, y > 1752 (in the U.K.) */
	{
		int tVar[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
		int modifiedYear = year - (month < 3 ? 1 : 0);
		return (modifiedYear + modifiedYear / 4 - modifiedYear / 100 + modifiedYear / 400 + tVar[month - 1] + day) % 7;
	}

	/**
	 * Checks if given year is a leap year
	 * 
	 * @param year
	 * @return
	 */
	public static boolean isLeapYear(int year) {
		return (year % 400 == 0) || ((year % 4 == 0) && (year % 100 != 0));
	}

	/**
	 * Returns a the calendar for the month in an ArrayList form
	 * 
	 * @param month
	 * @param startDay
	 * @param year
	 * @return
	 */
	public static ArrayList<ArrayList<String>> getCalArrayForMonth(int month, int startDay, int year) {
		int[] days = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		ArrayList<ArrayList<String>> daysInMonth = new ArrayList<ArrayList<String>>();
		if (month == 2 && isLeapYear(year)) {
			days[month] = 29;
		}

		ArrayList<String> week = new ArrayList<String>();
		for (int i = 0; i < startDay; i++) {
			week.add("   ");
		}
		for (int i = 1; i <= days[month]; i++) {
			String temp = String.format("%2d ", i);
			week.add(temp);
			if (((i + startDay) % 7 == 0) || (i == days[month])) {
				daysInMonth.add(week);
				week = new ArrayList<String>();
			}
		}

		return daysInMonth;
	}

	/**
	 * Prints the calendar
	 * 
	 * @param args
	 *            String containing command and arguments to print the calendar
	 *            of the current month
	 * @return
	 */
	@Override
	public String printCal(String args) {
		String[] argsSplit = args.split(",");
		String str = "";

		int month = Integer.parseInt(argsSplit[0]); // month
		int year = Integer.parseInt(argsSplit[1]); // year

		str += ("   " + months[month] + SPACE + year) + System.getProperty(LINE_SEPARATOR);
		str += ("Su Mo Tu We Th Fr Sa") + System.getProperty(LINE_SEPARATOR);

		ArrayList<ArrayList<String>> tempLoop = getCalArrayForMonth(month, dayOfWeek(month, 1, year), year);

		for (int a = 0; a < tempLoop.size(); a++) {
			for (int j = 0; j < tempLoop.get(a).size(); j++) {
				str += tempLoop.get(a).get(j);
			}
			str += System.getProperty(LINE_SEPARATOR);
		}
		return str;
	}

	/**
	 * Print calendar for a particular month and year
	 * 
	 * @param args
	 *            String containing command and arguments
	 * @return
	 */
	@Override
	public String printCalForMonthYear(String args) {
		return printCal(args);
	}

	/**
	 * Create a 3 by 4 grid calendar
	 * 
	 * @param args
	 * @return
	 */
	public String create3by4Cal(String args) {
		String[] argsSplit = args.split(",");
		String str = "";

		int type = Integer.parseInt(argsSplit[0]); // monday or sunday first: 1
													// for sunday, 0 for monday
		int year = Integer.parseInt(argsSplit[1]); // year

		ArrayList<ArrayList<ArrayList<String>>> allMonths = new ArrayList<ArrayList<ArrayList<String>>>();

		for (int i = 1; i < months.length; i++) {
			// starting day
			int day = dayOfWeek(i, type, year);

			ArrayList<ArrayList<String>> daysInMonth = getCalArrayForMonth(i, day, year);
			allMonths.add(daysInMonth);
		}

		// Row of 4
		for (int x = 0; x < 4; x++) {
			int start = x * 1 * 3;
			int maxSize = 4;

			// Add row for months (3 months)
			for (int z = start; z < start + 3; z++) {
				if (z == 4 || z == 5) {
					str += ("    ");
				}
				str += ("     " + months[z + 1] + SPACE + year + "     ");
				if (maxSize < allMonths.get(z).size()) {
					maxSize = allMonths.get(z).size();
				}
			}
			str += System.getProperty(LINE_SEPARATOR);

			// Add row for weeks (3 blocks)
			for (int z = 0; z < 3; z++) {
				if (type == 1) {
					str += ("Su Mo Tu We Th Fr Sa");
				} else if (type == 0) {
					str += ("Mo Tu We Th Fr Sa Su");
				}
				str += SPACE;
				str += ("  ");
			}
			str += System.getProperty(LINE_SEPARATOR);

			// Create row for months
			for (int f = 0; f < maxSize; f++) {
				for (int q = start; q < start + 3; q++) {
					int monthy = allMonths.get(q).size();
					if (f < monthy) {
						for (int c = 0; c < allMonths.get(q).get(f).size(); c++) {
							str += (allMonths.get(q).get(f).get(c));
						}
						if (allMonths.get(q).get(f).size() != 7) {
							for (int c = 0; c < 7 - allMonths.get(q).get(f).size(); c++) {
								str += ("   ");
							}
						}
						str += ("  ");
					} else {
						for (int c = 0; c < 7; c++) {
							str += ("   ");
						}
						str += ("  ");
					}
				}
				str += System.getProperty(LINE_SEPARATOR);
			}
		}

		return str;
	}

	/**
	 * Returns a string that prints the calendar for the year.
	 * 
	 * @param args
	 *            String containing command and arguments
	 * @return
	 */
	@Override
	public String printCalForYear(String args) {
		return create3by4Cal("1," + args);
	}

	/**
	 * Returns a string that prints the calendar for a specific month and year
	 * with monday first.
	 * 
	 * @param args
	 *            String containing command and arguments
	 * @return
	 */
	@Override
	public String printCalForMonthYearMondayFirst(String args) {
		return printCalWithMondayFirst(args);
	}

	/**
	 * Returns a string that prints the calendar for the year with monday first.
	 * 
	 * @param args
	 *            String containing command and arguments
	 * @return
	 */
	@Override
	public String printCalForYearMondayFirst(String args) {
		return create3by4Cal("0," + args);
	}
}
