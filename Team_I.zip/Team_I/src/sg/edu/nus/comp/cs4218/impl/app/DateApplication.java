package sg.edu.nus.comp.cs4218.impl.app;

import sg.edu.nus.comp.cs4218.app.Date;
import sg.edu.nus.comp.cs4218.exception.DateException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class DateApplication implements Date{
	private java.util.Date currentDate;

	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws DateException {
	    if (stdout == null) {
	    	throw new DateException("OutputStream not provided");
	    }
	    
	    currentDate = new java.util.Date();
	    String finalStr = "";
	    
	    if (args.length == 0) {
	    	finalStr = printCurrentDate(null);
	    } else {
	    	throw new DateException("Illegal time format");
	    }

	    try {
            stdout.write(finalStr.getBytes());
            stdout.write(System.getProperty("line.separator").getBytes());
        } catch (IOException e) {
            throw new DateException("IOException");
        }
	}

	/**
	 * Returns a string that prints the current date. Arguments does not affect the value of print date.
	 * @param args No command is needed for date
	 * @return
	 */
	@Override
	public String printCurrentDate(String args) {
		
		String[] daysName = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
		String[] months = {
		            "Jan", "Feb", "Mar",
		            "April", "May", "June",
		            "July", "Aug", "Sept",
		            "Oct", "Nov", "Dec"
		};
		@SuppressWarnings("deprecation")
		int currYear = currentDate.getYear() + 1900, currMonth = currentDate.getMonth(),
            currDay = currentDate.getDay(), currDate = currentDate.getDate(),
            currHr = currentDate.getHours(), currMin = currentDate.getMinutes(),
            currSec = currentDate.getSeconds();

		StringBuilder res = new StringBuilder();
		res.append(daysName[currDay] + " ");
		res.append(months[currMonth] + " ");
		res.append(currDate + " ");
        res.append(currHr < 10 ? "0" + currHr: currHr);
        res.append(":");
        res.append(currMin < 10 ? "0" + currMin : currMin);
        res.append(":");
        res.append(currSec < 10 ? "0" + currSec + " " : currSec + " " );
		res.append("SGT" + " ");
		res.append(currYear);

		return res.toString();// temp stub for test case
	}

}
