package sg.edu.nus.comp.cs4218;

import sg.edu.nus.comp.cs4218.exception.InvalidFileOrDirException;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

public final class Environment {
	
	/**
	 * Java VM does not support changing the current working directory. 
	 * For this reason, we use Environment.currentDirectory instead.
	 */
	public static volatile String currentDirectory = System.getProperty("user.dir");
	
	
	private Environment() {
	};

    /**
     *
     * @param finalDirStr
     * @throws IOException
     */
    public static void setCurrentDirectory(String prevDir, String finalDirStr)
            throws IOException, InvalidFileOrDirException {

        if (Paths.get(finalDirStr).isAbsolute()) {
            File finalDir = new File(finalDirStr);

            if(finalDir.isDirectory()) {
                currentDirectory = finalDirStr;
            } else {
                throw new InvalidFileOrDirException(finalDirStr + ": " + "No such file or directory");
            }
            return;
        }

        String destDir = prevDir + File.separator + finalDirStr;
        File finalDir = new File(destDir);

        if(!finalDir.exists()) {
            throw new InvalidFileOrDirException(destDir + ": " + "No such file or directory");
        }

        if(finalDir.isFile()) {
            throw new InvalidFileOrDirException(destDir + ": " + "Not a directory");
        }

        if (!finalDir.isAbsolute()) {
            finalDir = new File(Environment.currentDirectory, destDir);
            currentDirectory = finalDir.getCanonicalPath();
            return;
        }

        currentDirectory = finalDir.getCanonicalPath();
    }

    public static String checkFileOrDir(String finalDirStr)
            throws IOException, InvalidFileOrDirException {

        File finalDir = new File(finalDirStr);

        if (!finalDir.exists() || !finalDir.isFile()) {
            throw new InvalidFileOrDirException(finalDirStr + ": " + "No such file or directory");
        }
        else if (!finalDir.isAbsolute()) {
            finalDir = new File(Environment.currentDirectory, finalDirStr);
        }

        return finalDir.getCanonicalPath();
    }

}
