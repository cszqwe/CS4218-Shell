package sg.edu.nus.comp.cs4218.impl.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.app.Sort;
import sg.edu.nus.comp.cs4218.exception.SortException;

/**
 * The sort command orders the lines of the specified file or input and prints the same lines but in sorted order.
 * It compares each line character by character. A special character (e.g., +) comes before numbers.
 * A number comes before capital letters. A capital letter comes before small letters, etc.
 * Within each character class, the characters are sorted according to their ASCII value.
 * 
 * <p>
 * <b>Command format:</b> <code>sort [-n] [FILE]...</code>
 * <dl>
 * <dt>-n</dt>
 * <dd>If specified, treat the first word of a line as a number.
 * <dt>FILE</dt>
 * <dd>the name of the file(s). If no files are specified, use stdin.</dd>
 * </dl>
 * </p>
 */

public class SortApplication implements Sort {
	final String NULL_ARGUMENT = "Null argument";
	final String patternSimple = "^[a-z]+$";
	final String patternCapital = "^[A-Z]+$";
	final String patternNumbers = "^[0-9]+$";
	final String patternSpecialChars = "^[^A-Za-z0-9]+$";
	final String patternSimpleCapital = "^[a-zA-Z]+$";
	final String patternSimpleNumbers = "^[a-z0-9]+$";
	final String patternSimpleSpecialChars = "^[a-z[^A-Za-z0-9]]+$";
	final String patternCapitalNumbers = "^[A-Z0-9]+$";
	final String patternCapitalSpecialChars = "^[A-Z[^A-Za-z0-9]]+$";
	final String patternNumbersSpecialChars = "^[0-9[^A-Za-z0-9]]+$";
	final String patternSimpleCapitalNumber = "^[a-zA-Z0-9]+$";
	final String patternSimpleCapitalSpecialChars = "^[a-zA-Z[^A-Za-z0-9]]+$";
	final String patternSimpleNumbersSpecialChars = "^[a-z0-9[^A-Za-z0-9]]+$";
	final String patternCapitalNumbersSpecialChars = "^[A-Z0-9[^A-Za-z0-9]]+$";
	final String patternAll = ".";
	private boolean hasIndicator = false;
	/**
	 * Runs the sort application with the specified arguments.
	 * 
	 * @param args
	 *            Array of arguments for the application. Each array element is
	 *            the path to a file. If no files are specified stdin is used.
	 * @param stdin
	 *            An InputStream. The input for the command is read from this
	 *            InputStream if no files are specified.
	 * @param stdout
	 *            An OutputStream. The output of the command is written to this
	 *            OutputStream.
	 * 
	 * @throws SortException
	 *             If the file(s) specified do not exist or are unreadable.
	 */
	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws SortException {
		if (args == null) {
			throw new SortException("Insufficient Parameters");
		} else {
			if ((args.length == 0 || (args.length == 1 && args[0].equals("-n"))) && stdin != null) {
				String line;
				String unsortedLines = "";

				BufferedReader bf = new BufferedReader(new InputStreamReader(stdin));
			    try {
					while((line = bf.readLine()) != null ) { 
						unsortedLines = unsortedLines + line + System.lineSeparator();
					}
					String sortedLines = sort(unsortedLines, null);

					writeToOutputStream(sortedLines, stdout);
				} catch (IOException e) {
					throw new SortException(e.getMessage());
				}  
			} else if (args.length >= 1) {
				int startIndex = 0;
				
				if(args[0].equals("-n")) {
					startIndex = 1;
					hasIndicator = true;
				}
				
				String unsortedLines = "";
				
				Path filePath;
				Path currentDir = Paths.get(Environment.currentDirectory);
				
				for (int i = startIndex; i < args.length; i++) {
					filePath = currentDir.resolve(args[i]);
					if (checkIfFileIsReadable(args[i])) {
						try {
							byte[] byteFileArray = Files
									.readAllBytes(filePath);
							String fileStr = new String(byteFileArray);
							unsortedLines = unsortedLines + fileStr;	
						} catch (IOException e) {
							throw new SortException(
									"Could not write to output stream");
						}
					}
				}
				
				String sortedLines = sort(unsortedLines, null);
		
				writeToOutputStream(sortedLines, stdout);
			} else {
				throw new SortException("Insufficient Parameters");
			}
		}
	}
	
	/**
	 * Checks if a file is readable.
	 * 
	 * @param filePath
	 *            The path to the file
	 * @return True if the file is readable.
	 * @throws SortException
	 *             If the file is not readable
	 */
	public boolean checkIfFileIsReadable(String filePathStr) throws SortException {
		if (filePathStr == null || filePathStr == "") {
			throw new SortException(filePathStr + ": No such file or directory");
		}
		
		Path filePath = Paths.get(filePathStr);
		
		if (Files.isDirectory(filePath)) {
			String pathStr = filePath.getFileName().toString();
			if(filePathStr.substring(filePathStr.length() - 1).equals("/")) {
				pathStr = pathStr + "/";
			}
			throw new SortException(pathStr + ": Is a directory");
		}
		if (Files.exists(filePath) && Files.isReadable(filePath)) {
			return true;
		} else {
			throw new SortException(filePathStr + ": No such file or directory");
		}
	}
	
	/**
	 * Sort lines with the rule of comparing each line character by character.
	 * 
	 * @param unsortedLines
	 *            All lines in unsorted order
	 *        patternStr
	 *            Regex pattern that used to filter out the lines
	 * @return Sorted lines in array
	 */
	String sort(String unsortedLines, String patternStr) {
		if (unsortedLines == null) {
			return NULL_ARGUMENT;
		}
		
		String[] unsortedLinesArr = unsortedLines.split(System.lineSeparator());
		String[] filteredUnsortedLinesArr;
		
		if(patternStr != null){
			Pattern pattern = Pattern.compile(patternStr);
			ArrayList<String> filteredUnsortedLinesList = new ArrayList<String>();
			for(int i = 0; i < unsortedLinesArr.length; i++){
				Matcher matcher = pattern.matcher(unsortedLinesArr[i]);
				if (matcher.find()) {
					filteredUnsortedLinesList.add(unsortedLinesArr[i]);
				}
			}
			filteredUnsortedLinesArr = new String[filteredUnsortedLinesList.size()];
			filteredUnsortedLinesArr = filteredUnsortedLinesList.toArray(filteredUnsortedLinesArr);
		}
		else{
			filteredUnsortedLinesArr = unsortedLinesArr;
		}

		String temp;
		for (int i = 0; i < filteredUnsortedLinesArr.length - 1; i++) {
 
			for (int j = 1; j < filteredUnsortedLinesArr.length - i; j++) {
				if (hasIndicator) {
					String[] firstSplit = filteredUnsortedLinesArr[j - 1].split(" ");
					String[] secondSplit = filteredUnsortedLinesArr[j].split(" ");
					int firstInt = extractInt(firstSplit[0]);
					int secondInt = extractInt(secondSplit[0]);
					
					if (firstInt > secondInt) {
						temp = filteredUnsortedLinesArr[j - 1];
						filteredUnsortedLinesArr[j - 1] = filteredUnsortedLinesArr[j];
						filteredUnsortedLinesArr[j] = temp;
					} else if (firstInt == secondInt) {
						if (filteredUnsortedLinesArr[j - 1].compareTo(filteredUnsortedLinesArr[j]) > 0) {
							temp = filteredUnsortedLinesArr[j - 1];
							filteredUnsortedLinesArr[j - 1] = filteredUnsortedLinesArr[j];
							filteredUnsortedLinesArr[j] = temp;
						}
					}
					
				} else if (filteredUnsortedLinesArr[j - 1].compareTo(filteredUnsortedLinesArr[j]) > 0) {
					temp = filteredUnsortedLinesArr[j - 1];
					filteredUnsortedLinesArr[j - 1] = filteredUnsortedLinesArr[j];
					filteredUnsortedLinesArr[j] = temp;
				}
			}
		}
		
		String sortedLines = "";

		for (int i = 0; i < filteredUnsortedLinesArr.length; i++) {
			sortedLines = sortedLines + filteredUnsortedLinesArr[i] + System.lineSeparator();
		}
		
		return sortedLines;
	}
	
	/**
	 * Extract the leading integer of the word
	 * 
	 * @param word
	 *            The first word of the line
	 * @return Extracted leading integer of the first word
	 */
	public int extractInt(String word) {
		if (word == null) {
			return -1;
		}
		int index = -1;
		while(index + 1 < word.length() && Character.isDigit(word.charAt(index + 1))) {
			index += 1;
		}
		if (index == -1) {
			return -1;
		} 
		
		index ++;
		return Integer.valueOf(word.substring(0, index));
	}
	
	/**
	 * Write input string to given output stream
	 * 
	 * @param str
	 *            Target string to be output
	 * @param stdout
	 *            Target output stream to be written
	 * @throws SortException
	 */
	public void writeToOutputStream(String str, OutputStream stdout) throws SortException {
		if (stdout == null) {
			throw new SortException("Null output stream");
		}
		try {
			if (str == null) {
				stdout.write("sort: Null Arguments\n".getBytes());
			} else {
				stdout.write(str.getBytes());
			}
		} catch (IOException e) {
			throw new SortException("Could not write to output stream");
		}
	}

	@Override
	public String sortStringsSimple(String toSort) {
		return sort(toSort, patternSimple);
	}

	@Override
	public String sortStringsCapital(String toSort) {
		return sort(toSort, patternCapital);
	}

	@Override
	public String sortNumbers(String toSort) {
		return sort(toSort, patternNumbers);
	}

	@Override
	public String sortSpecialChars(String toSort) {
		return sort(toSort, patternSpecialChars);
	}

	@Override
	public String sortSimpleCapital(String toSort) {
		return sort(toSort, patternSimpleCapital);
	}

	@Override
	public String sortSimpleNumbers(String toSort) {
		return sort(toSort, patternSimpleNumbers);
	}

	@Override
	public String sortSimpleSpecialChars(String toSort) {
		return sort(toSort, patternSimpleSpecialChars);
	}

	@Override
	public String sortCapitalNumbers(String toSort) {
		return sort(toSort, patternCapitalNumbers);
	}

	@Override
	public String sortCapitalSpecialChars(String toSort) {
		return sort(toSort, patternCapitalSpecialChars);
	}

	@Override
	public String sortNumbersSpecialChars(String toSort) {
		return sort(toSort, patternNumbersSpecialChars);
	}

	@Override
	public String sortSimpleCapitalNumber(String toSort) {
		return sort(toSort, patternSimpleCapitalNumber);
	}

	@Override
	public String sortSimpleCapitalSpecialChars(String toSort) {
		return sort(toSort,patternSimpleCapitalSpecialChars);
	}

	@Override
	public String sortSimpleNumbersSpecialChars(String toSort) {
		return sort(toSort, patternSimpleNumbersSpecialChars);
	}

	@Override
	public String sortCapitalNumbersSpecialChars(String toSort) {
		return sort(toSort, patternCapitalNumbersSpecialChars);
	}

	@Override
	public String sortAll(String toSort) {
		return sort(toSort, patternAll);
	}
}
