package sg.edu.nus.comp.cs4218.impl.app;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.PwdException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class PwdApplication implements Application {
    @Override
    public void run(String[] args, InputStream stdin, OutputStream stdout) throws PwdException {
        if (args == null) {
            throw new PwdException("Null arguments");
        }

        if (stdout == null) {
            throw new PwdException("OutputStream not provided");
        }

        String currentDir;
        try {
            currentDir = Environment.currentDirectory;
            stdout.write(currentDir.getBytes());
            stdout.write(System.lineSeparator().getBytes());
        } catch (IOException e) {
            throw new PwdException("IOException");
        }
    }
}
