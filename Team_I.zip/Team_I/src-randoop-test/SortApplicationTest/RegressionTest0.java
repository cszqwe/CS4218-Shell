import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test01");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        try {
            boolean b2 = sortApplication0.checkIfFileIsReadable("hi!");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SortException");
        } catch (sg.edu.nus.comp.cs4218.exception.SortException e) {
        }
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test02");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        try {
            boolean b4 = sortApplication0.checkIfFileIsReadable("");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SortException");
        } catch (sg.edu.nus.comp.cs4218.exception.SortException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test03");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortSimpleNumbers("hi!");
        try {
            boolean b6 = sortApplication0.checkIfFileIsReadable("");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SortException");
        } catch (sg.edu.nus.comp.cs4218.exception.SortException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test04");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortSimpleSpecialChars("hi!");
        java.lang.String str6 = sortApplication0.sortSimpleCapitalNumber("hi!\n");
        java.lang.String str8 = sortApplication0.sortSimpleNumbers("hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!\n" + "'", str4.equals("hi!\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test05");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalSpecialChars("hi!");
        java.lang.String str4 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str6 = sortApplication0.sortSpecialChars("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test06");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortCapitalNumbersSpecialChars("hi!\n");
        java.lang.String str6 = sortApplication0.sortSimpleNumbersSpecialChars("hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!\n" + "'", str6.equals("hi!\n"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test07");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortSimpleNumbers("hi!");
        java.lang.String str6 = sortApplication0.sortAll("");
        java.lang.String str8 = sortApplication0.sortStringsSimple("");
        java.lang.String str10 = sortApplication0.sortCapitalNumbersSpecialChars("hi!\n");
        try {
            boolean b12 = sortApplication0.checkIfFileIsReadable("hi!\n");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SortException");
        } catch (sg.edu.nus.comp.cs4218.exception.SortException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test08");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortSimpleSpecialChars("hi!");
        java.lang.String str6 = sortApplication0.sortSimpleNumbersSpecialChars("hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!\n" + "'", str4.equals("hi!\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!\n" + "'", str6.equals("hi!\n"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test09");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortStringsCapital("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test10");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalSpecialChars("hi!");
        java.lang.String str4 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str6 = sortApplication0.sortCapitalNumbers("hi!");
        java.lang.String str8 = sortApplication0.sortCapitalSpecialChars("");
        java.lang.String str10 = sortApplication0.sortSimpleNumbersSpecialChars("hi!\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!\n" + "'", str10.equals("hi!\n"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test11");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortSimpleNumbers("");
        java.lang.String str4 = sortApplication0.sortStringsSimple("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test12");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortSimpleNumbers("hi!");
        java.lang.String str6 = sortApplication0.sortSimpleCapitalNumber("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test13");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortSimpleNumbers("hi!");
        java.lang.String str6 = sortApplication0.sortCapitalNumbersSpecialChars("");
        java.lang.String str8 = sortApplication0.sortCapitalNumbers("hi!");
        java.lang.String str10 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str12 = sortApplication0.sortSimpleCapitalSpecialChars("hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!\n" + "'", str12.equals("hi!\n"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test14");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortSimpleNumbers("hi!");
        java.lang.String str6 = sortApplication0.sortAll("");
        java.lang.String str8 = sortApplication0.sortStringsSimple("");
        java.lang.String str10 = sortApplication0.sortCapitalNumbersSpecialChars("hi!\n");
        java.lang.String str12 = sortApplication0.sortSimpleNumbersSpecialChars("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test15");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortSimpleNumbers("");
        java.lang.String str4 = sortApplication0.sortStringsCapital("");
        java.lang.String str6 = sortApplication0.sortSpecialChars("");
        java.lang.String str8 = sortApplication0.sortCapitalSpecialChars("hi!\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test16");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortNumbersSpecialChars("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test17");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortCapitalNumbersSpecialChars("hi!\n");
        java.lang.String str6 = sortApplication0.sortCapitalNumbersSpecialChars("hi!");
        java.lang.String str8 = sortApplication0.sortCapitalNumbersSpecialChars("hi!\n");
        java.lang.String str10 = sortApplication0.sortSimpleSpecialChars("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test18");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortCapitalNumbersSpecialChars("hi!\n");
        java.lang.String str6 = sortApplication0.sortSimpleCapitalNumber("hi!");
        java.lang.String str8 = sortApplication0.sortAll("hi!\n");
        java.lang.String str10 = sortApplication0.sortSimpleCapital("");
        java.lang.String str12 = sortApplication0.sortSimpleCapitalSpecialChars("hi!\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!\n" + "'", str8.equals("hi!\n"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!\n" + "'", str12.equals("hi!\n"));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test19");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalSpecialChars("hi!");
        java.lang.String str4 = sortApplication0.sortSimpleNumbers("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test20");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalSpecialChars("hi!");
        java.lang.String str4 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str6 = sortApplication0.sortCapitalNumbers("hi!");
        java.lang.String str8 = sortApplication0.sortCapitalSpecialChars("");
        java.lang.String str10 = sortApplication0.sortCapitalNumbersSpecialChars("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test21");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalNumbers("");
        java.lang.String str4 = sortApplication0.sortSimpleSpecialChars("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test22");
        sg.edu.nus.comp.cs4218.impl.app.SortApplication sortApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SortApplication();
        java.lang.String str2 = sortApplication0.sortCapitalSpecialChars("hi!");
        java.lang.String str4 = sortApplication0.sortSpecialChars("");
        java.lang.String[] str_array8 = new java.lang.String[] { "hi!", "", "" };
        java.io.InputStream inputStream9 = null;
        java.io.OutputStream outputStream10 = null;
        try {
            sortApplication0.run(str_array8, inputStream9, outputStream10);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SortException");
        } catch (sg.edu.nus.comp.cs4218.exception.SortException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(str_array8);
    }
}

