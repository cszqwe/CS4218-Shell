package sg.edu.nus.comp.cs4218.impl.app;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.HeadException;
import sg.edu.nus.comp.cs4218.exception.InvalidFileOrDirException;

import java.io.*;

public class HeadApplication implements Application {
    @Override
    public void run(String[] args, InputStream stdin, OutputStream stdout) throws HeadException {
        if (args == null) {
            throw new HeadException("Null arguments");
        }

        if (stdout == null) {
            throw new HeadException("OutputStream not provided");
        }

        BufferedReader reader = null;

        // Print 10 lines if not specified
        int linesToPrint = 10;

        // Case when no file is specified: head "test"
        if (args.length == 0) {
            if (stdin == null) {
                throw new HeadException("InputStream not provided");
            }
            reader = new BufferedReader(new InputStreamReader(stdin));
            printHead(linesToPrint, stdout, reader);
        }
        // Case when only file name is given: head test.txt
        else if (args.length == 1) {
            printHeadForFile(args[0], linesToPrint, stdout);
        }
        // Case when options and file is given
        else if (args.length == 2 || args.length == 3) {

            if (args[0].equals("-n")) {
                if(!args[1].matches("-?\\d+(\\.\\d+)?")) {
                    throw new HeadException("illegal line count");
                }

                linesToPrint = numberStrCheck(args[1]);

                if (args.length == 2) {
                    if (stdin == null) {
                        throw new HeadException("InputStream not provided");
                    }

                    reader = new BufferedReader(
                            new InputStreamReader(stdin));

                    printHead(linesToPrint, stdout, reader);
                } else {
                    printHeadForFile(args[2], linesToPrint, stdout);
                }
            } else {
                throw new HeadException("Invalid options");
            }
        } else if (args.length > 3) {

            int optIndex = 0;
            for(int i = 0; i < args.length; i++) {
                if(args[i].equals("-n")) {
                    optIndex = i;
                }
            }
            // Case: head -n 15 -n 15 -n
            if(optIndex + 1 == args.length) {
                throw new HeadException("Invalid arguments");
            }

            // head -n 15 -n 15 < test.txt
            if(optIndex + 2 == args.length) {
                if (stdin == null) {
                    throw new HeadException("InputStream not provided");
                }

                linesToPrint = numberStrCheck(args[optIndex + 1]);

                reader = new BufferedReader(
                        new InputStreamReader(stdin));

                printHead(linesToPrint, stdout, reader);
            }

            // Case: head -n 15 -n 5 test.txt
            else {
                linesToPrint = numberStrCheck(args[optIndex + 1]);

                printHeadForFile(args[optIndex + 2], linesToPrint, stdout);
            }
        }

    }

    public int numberStrCheck(String num) throws HeadException {
        if(!num.matches("-?\\d+(\\.\\d+)?")) {
            throw new HeadException("illegal line count");
        }

        int intNum = Integer.parseInt(num);

        if(intNum < 0) {
            throw new HeadException("illegal line count");
        }
        return intNum;
    }

    public void printHeadForFile(String file, int linesToPrint, OutputStream stdout) throws HeadException{
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(
                    Environment.checkFileOrDir(file)));
        } catch (IOException e) {
            throw new HeadException("IOException");
        } catch (InvalidFileOrDirException e) {
            throw new HeadException(e.getMessage());
        }

        printHead(linesToPrint, stdout, reader);
    }

    public void printHead(int linesToPrint, OutputStream stdout,
                                      BufferedReader reader) throws HeadException {

        String line;
        try {
            for (int i = 0; i < linesToPrint; i++) {
                if ((line = reader.readLine()) == null) {
                    break;
                } else {
                    stdout.write(line.getBytes());
                }
                stdout.write(System.getProperty("line.separator").getBytes());
            }
            reader.close();
        } catch (IOException e) {
            throw new HeadException("IOException");
        }
    }
}
