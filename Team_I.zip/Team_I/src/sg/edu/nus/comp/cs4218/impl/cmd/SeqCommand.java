package sg.edu.nus.comp.cs4218.impl.cmd;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;

import sg.edu.nus.comp.cs4218.Command;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;

/**
 * A Seq Command is a command consisting of semicolon
 * 
 * <p>
 * <b>Command format:</b> <code>(&lt;non-Keyword&gt; | &lt;quoted&gt;)*</code>
 * </p>
 */

public class SeqCommand implements Command {
	static final Character DOUBLE_QUOTE = '"';
	static final Character SINGLE_QUOTE = '\'';
	static final Character SEMICOLON = ';';
	
	String cmdline;
	Boolean error;
	String errorMsg;

	public SeqCommand(String cmdline) {
		this.cmdline = cmdline.trim();
		error = false;
		errorMsg = "";
	}
	
	@Override
	public void evaluate(InputStream stdin, OutputStream stdout) throws AbstractApplicationException, ShellException {
		if (error) {
			throw new ShellException(errorMsg);
		}
		String command = "";
		HashMap<String, Integer> tokensMap = new HashMap<String, Integer>();
		tokensMap.put("startDQ", -1);
		tokensMap.put("endDQ", -1);
		tokensMap.put("startSQ", -1);
		tokensMap.put("endSQ", -1);
		
		boolean hasDoubleQuote = false;
		boolean hasSingleQuote = false;
		
		for (int i = 0; i < cmdline.length(); i++) {
			if (cmdline.charAt(i) == SEMICOLON) {
				int startDQ = tokensMap.get("startDQ");
				int endDQ = tokensMap.get("endDQ");
				int startSQ = tokensMap.get("startSQ");
				int endSQ = tokensMap.get("endSQ");
				if ((startDQ == -1 && endDQ == -1 && startSQ == -1 && endSQ == -1)
					 || (startDQ != -1 && endDQ != -1 && i > endDQ)
					 || (startSQ != -1 && endSQ != -1 && i > endSQ)) {
					CallCommand callCommand = new CallCommand(command);		    	
					callCommand.evaluate(null, stdout);
					command = "";
					tokensMap.put("startDQ", -1);
					tokensMap.put("endDQ", -1);
					tokensMap.put("startSQ", -1);
					tokensMap.put("endSQ", -1);
					continue;
				}
			} else if (cmdline.charAt(i) == DOUBLE_QUOTE) {
				if(!hasDoubleQuote) {
					tokensMap.put("startDQ", i);
				} else {
					tokensMap.put("endDQ", i);
				}
				hasDoubleQuote = !hasDoubleQuote;
			} else if (cmdline.charAt(i) == SINGLE_QUOTE) {
				if(!hasSingleQuote) {
					tokensMap.put("startSQ", i);
				} else {
					tokensMap.put("endSQ", i);
				}
				hasSingleQuote = !hasSingleQuote;
			} 
			command = command + String.valueOf(cmdline.charAt(i));

			if (i + 1 == cmdline.length()) {
				CallCommand callCommand = new CallCommand(command);		    	
				callCommand.evaluate(null, stdout);
			}
		}	
	}

	@Override
	public void terminate() {
		// TODO Auto-generated method stub	
	}
}
