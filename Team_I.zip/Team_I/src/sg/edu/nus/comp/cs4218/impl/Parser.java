package sg.edu.nus.comp.cs4218.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sg.edu.nus.comp.cs4218.exception.ShellException;

/**
 * The Parser receives string command and check if it contains SEMICOLON (;) or
 * PIPE (|) separator
 * 
 */
public class Parser {
	public static final String COMMAND_TYPE_CALL = "COMMAND_TYPE_CALL";
	public static final String COMMAND_TYPE_SEQ = "COMMAND_TYPE_SEQ";
	public static final String COMMAND_TYPE_PIPE = "COMMAND_TYPE_PIPE";

	public static final String SEMICOLON = ";";
	public static final String PIPE = "|";

	public static final String[] VALID_COMMANDS = { "cat", "echo", "cd", "cal", "pwd", "head", "tail", "grep", "sort",
			"date", "wc", "sed" };

	private String cmdLine;
	private String commandType;

	public Parser(String cmdLine) {
		this.cmdLine = cmdLine.trim();
		this.commandType = COMMAND_TYPE_CALL;
	}

	/**
	 * Evaluates command using data provided through stdin stream. Writes result
	 * to commandType
	 * 
	 * @throws ShellException
	 * 
	 */
	public void evaluate() throws ShellException {
		String firstArg = this.cmdLine.split(" ")[0];
		boolean isValid = false;
		for (int i = 0; i < VALID_COMMANDS.length; i++) {
			if (firstArg.equalsIgnoreCase(VALID_COMMANDS[i])) {
				isValid = true;
				break;
			}
		}

		if (!isValid) {
			throw new ShellException(firstArg + ": " + ShellImpl.EXP_INVALID_APP);
		}

//		String patternBQinBQ = "`(.*`[^\\n`]*`.*)`";
//		Pattern patternBQinBQp = Pattern.compile(patternBQinBQ);
//		Matcher matcherBQinBQ = patternBQinBQp.matcher(cmdLine);
//		if (matcherBQinBQ.find()) {
//			throw new ShellException(ShellImpl.EXP_SYNTAX);
//		}
		if (this.cmdLine.indexOf(';') != -1) {
			this.commandType = COMMAND_TYPE_SEQ;
		} else if (this.cmdLine.indexOf('|') != -1) {
			this.commandType = COMMAND_TYPE_PIPE;
		}
	}

	/**
	 * Get the type of command
	 * 
	 * @return command type in String
	 */
	public String getType() {
		return this.commandType;
	}
	
	public static void checkInvalidNestedBackQuote(String cmd) throws ShellException {
		String patternBQinBQ = "`(.*`[^\\n`]*`.*)`";
		Pattern patternBQinBQp = Pattern.compile(patternBQinBQ);
		Matcher matcherBQinBQ = patternBQinBQp.matcher(cmd);
		if (matcherBQinBQ.find()) {
			throw new ShellException(ShellImpl.EXP_SYNTAX);
		}
	}
}
