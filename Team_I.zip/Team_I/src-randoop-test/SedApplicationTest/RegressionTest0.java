import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test01");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        try {
            java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidReplacement("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test02");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String[] str_array7 = new java.lang.String[] { "", "hi!", "hi!", "!", "!", "!" };
        java.io.InputStream inputStream8 = null;
        java.io.OutputStream outputStream9 = null;
        try {
            sedApplication0.run(str_array7, inputStream8, outputStream9);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertNotNull(str_array7);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test03");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidRegex("hi!");
        try {
            java.lang.String str4 = sedApplication0.replaceSubstringWithInvalidReplacement("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test04");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidRegex("hi!");
        java.lang.String[] str_array3 = null;
        java.io.InputStream inputStream4 = null;
        java.io.OutputStream outputStream5 = null;
        try {
            sedApplication0.run(str_array3, inputStream4, outputStream5);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test05");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String[] str_array2 = new java.lang.String[] { "hi!" };
        java.io.InputStream inputStream3 = null;
        java.io.OutputStream outputStream4 = null;
        try {
            sedApplication0.run(str_array2, inputStream3, outputStream4);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertNotNull(str_array2);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test06");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        try {
            java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidRegex("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test07");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String[] str_array6 = new java.lang.String[] { "hi!", "", "!", "hi!", "hi!" };
        java.io.InputStream inputStream7 = null;
        java.io.OutputStream outputStream8 = null;
        try {
            sedApplication0.run(str_array6, inputStream7, outputStream8);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertNotNull(str_array6);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test08");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        try {
            java.lang.String str4 = sedApplication0.replaceSubstringWithInvalidRegex("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test09");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        java.lang.String[] str_array5 = new java.lang.String[] { "", "hi!" };
        java.io.InputStream inputStream6 = null;
        java.io.OutputStream outputStream7 = null;
        try {
            sedApplication0.run(str_array5, inputStream6, outputStream7);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
        org.junit.Assert.assertNotNull(str_array5);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test10");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        java.lang.String[] str_array3 = null;
        java.io.InputStream inputStream4 = null;
        java.io.OutputStream outputStream5 = null;
        try {
            sedApplication0.run(str_array3, inputStream4, outputStream5);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test11");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String[] str_array7 = new java.lang.String[] { "", "!", "!", "", "!", "hi!" };
        java.io.InputStream inputStream8 = null;
        java.io.OutputStream outputStream9 = null;
        try {
            sedApplication0.run(str_array7, inputStream8, outputStream9);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertNotNull(str_array7);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test12");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        java.lang.String str4 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        try {
            java.lang.String str6 = sedApplication0.replaceSubstringWithInvalidRegex("!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!" + "'", str4.equals("!"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test13");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        java.lang.String str4 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        try {
            java.lang.String str6 = sedApplication0.replaceSubstringWithInvalidRegex("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!" + "'", str4.equals("!"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test14");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        java.lang.String str4 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        java.lang.String[] str_array10 = new java.lang.String[] { "hi!", "!", "hi!", "hi!", "" };
        java.io.InputStream inputStream11 = null;
        java.io.OutputStream outputStream12 = null;
        try {
            sedApplication0.run(str_array10, inputStream11, outputStream12);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!" + "'", str4.equals("!"));
        org.junit.Assert.assertNotNull(str_array10);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test15");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        java.lang.String str4 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        try {
            java.lang.String str6 = sedApplication0.replaceSubstringWithInvalidReplacement("!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!" + "'", str4.equals("!"));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test16");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidRegex("hi!");
        java.lang.String str4 = sedApplication0.replaceSubstringWithInvalidReplacement("hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!" + "'", str4.equals("!"));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test17");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidRegex("hi!");
        java.lang.String[] str_array6 = new java.lang.String[] { "hi!", "hi!", "!" };
        java.io.InputStream inputStream7 = null;
        java.io.OutputStream outputStream8 = null;
        try {
            sedApplication0.run(str_array6, inputStream7, outputStream8);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
        org.junit.Assert.assertNotNull(str_array6);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test18");
        sg.edu.nus.comp.cs4218.impl.app.SedApplication sedApplication0 = new sg.edu.nus.comp.cs4218.impl.app.SedApplication();
        java.lang.String str2 = sedApplication0.replaceSubstringWithInvalidRegex("hi!");
        java.lang.String str4 = sedApplication0.replaceSubstringWithInvalidRegex("hi!");
        java.lang.String[] str_array7 = new java.lang.String[] { "hi!", "!" };
        java.io.InputStream inputStream8 = null;
        java.io.OutputStream outputStream9 = null;
        try {
            sedApplication0.run(str_array7, inputStream8, outputStream9);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.SedException");
        } catch (sg.edu.nus.comp.cs4218.exception.SedException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!" + "'", str4.equals("!"));
        org.junit.Assert.assertNotNull(str_array7);
    }
}

