package sg.edu.nus.comp.cs4218.app;

import sg.edu.nus.comp.cs4218.Application;

public interface Date extends Application{

	/**
	 * Returns a string that prints the current date. Arguments does not affect the value of print date.
	 * @param args No command is needed for date
	 * @return
	 */
	public String printCurrentDate(String args);

}
