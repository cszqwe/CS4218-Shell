package sg.edu.nus.comp.cs4218.exception;

public class InvalidFileOrDirException extends Exception{
	private static final long serialVersionUID = -1033087050276001619L;

	public InvalidFileOrDirException(String message) {
        super(message);
    }

}
