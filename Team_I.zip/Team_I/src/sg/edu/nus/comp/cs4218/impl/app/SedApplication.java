package sg.edu.nus.comp.cs4218.impl.app;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.regex.Pattern;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.exception.SedException;

public class SedApplication implements Application{

    private BufferedReader reader = null;
    private String[] inputStringByLines;
    private String[] regexInfo;

    @Override
    public void run(String[] args, InputStream stdin, OutputStream stdout) throws SedException {
        String inputString = null;
        Boolean isReplaceAll = false;
        Boolean isFileInput = false;

        if ((args == null) || (args.length == 0)) {
            throw new SedException("No arguments are provided.");
        }

        if ((stdin == null) && (args.length == 1)) {
            throw new SedException("No valid input is specified.");
        }

        if (args.length > 2) {
            throw new SedException("Invalid number of arguments are provided.");
        }

        if (stdout == null) {
            throw new SedException("No valid output is specified.");
        }

        // Setting the input to be from file specified
        if (args.length == 2) {
            try {
                reader = new BufferedReader(new FileReader(args[1]));
                isFileInput = true;
            } catch (FileNotFoundException e) {
                throw new SedException("No such file or directory.");
            }
        }

        // Setting the input to be from input stream specified
        if (args.length == 1) {
            reader = new BufferedReader(new InputStreamReader(stdin));
        }

        try {
            inputString = readInputString(reader);
        } catch (IOException e) {
            throw new SedException("IOException.");
        }

        isReplaceAll = parseValidInputString(args, inputString);

        String result;
        if (isFileInput) {
            if (isReplaceAll) {
                result = replaceAllSubstringsInFile(inputString);
            } else {
                result = replaceFirstSubStringInFile(inputString);
            }
        } else {
            if (isReplaceAll) {
                result = replaceAllSubstringsInStdin(inputString);
            } else {
                result = replaceFirstSubStringFromStdin(inputString);
            }
        }

        try {
            stdout.write(result.getBytes());
            stdout.write(System.lineSeparator().getBytes());
        } catch (IOException e) {
            throw new SedException("IOException");
        } 
//
//        try {
//            if (reader != null) reader.close();
//            if (stdin != null) stdin.close();
//            if (stdout != null) stdout.close();
//        } catch (IOException e) {
//            throw new SedException("IOException.");
//        }
    }

    /**
     * Parses the input string to retrieve information such as symbol used in replacement
     * @param args The arguments passed in by user
     * @param inputString The interpreted input string
     * @return Boolean whether the user wants to replace all occurence or first
     * @throws SedException
     */
    private Boolean parseValidInputString(String[] args, String inputString) throws SedException {
        Boolean isReplaceAll = false;
        String symbolUsed;
        inputStringByLines = inputString.split(System.getProperty("line.separator"));
        symbolUsed = Pattern.quote(Character.toString(args[0].charAt(1)));
        
        regexInfo = args[0].split(symbolUsed); 
        if ((!(regexInfo[0].equals("s"))) || ((regexInfo.length != 3) && (regexInfo.length != 4))) {
            throw new SedException("Invalid replacement expression.");
        }
        if (regexInfo.length == 4) {
            if (!(regexInfo[3].equals("g"))){
                throw new SedException("Invalid replacement expression for replace all.");
            } else {
                isReplaceAll = true;
            }
        }
        
        int numSymbolsUsed = 0;
        char c = args[0].charAt(1);
        for (int i = 0; i < args[0].length(); i++) {
            if (args[0].charAt(i) == c) {
                numSymbolsUsed++;
            }
        }
        if (numSymbolsUsed != 3) {
            throw new SedException("Number of symbols in input format is incorrect.");
        }
        
        return isReplaceAll;
    }

    /**
     * Reads the input and returns a string from the input (stream or file)
     * @param br Reader comprising of the input method desired
     * @throws SedException
     * @throws IOException
     */
    private String readInputString(BufferedReader br) throws SedException, IOException {
        String inputString;
        StringBuilder sb = new StringBuilder();
        try {
            if ((inputString = br.readLine()) != null) {
                sb.append(inputString);
            }

            while ((inputString = br.readLine()) != null) {
                sb.append(System.lineSeparator());
                sb.append(inputString);
            }

            inputString = sb.toString();  
        } catch (IOException e) {
            throw new SedException("IOException");
        } finally {
            if (br != null) br.close();           
        }

        return inputString;
    }

    /**
     * Returns string containing lines with the first matched substring replaced
     * in file
     * @param args String containing command and arguments
     */
    public String replaceFirstSubStringInFile(String args) {
        String replacedString = replaceFirstSubString(args);
        return replacedString;
    }

    /**
     * Returns string containing lines with all matched substring replaced in
     * file
     * @param args String containing command and arguments
     */
    public String replaceAllSubstringsInFile(String args) {
        String replacedString = replaceAllSubStrings(args);
        return replacedString;
    }

    /**
     * Returns string containing lines with first matched substring replaced in
     * Stdin
     * @param args String containing command and arguments
     */
    public String replaceFirstSubStringFromStdin(String args) {
        String replacedString = replaceFirstSubString(args);
        return replacedString;
    }

    /**
     * Returns string containing lines with all matched substring replaced in
     * Stdin
     * @param args String containing command and arguments
     */
    public String replaceAllSubstringsInStdin(String args) {
        String replacedString = replaceAllSubStrings(args);
        return replacedString;
    }

    /**
     * Returns string containing lines with first matched substring replaced
     * @param args String containing command and arguments
     */
    public String replaceFirstSubString(String args) {
        String oldString = regexInfo[1];
        String newString = regexInfo[2];
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < inputStringByLines.length; i++){
            inputStringByLines[i] = inputStringByLines[i].replaceFirst(Pattern.quote(oldString), newString);
            sb.append(inputStringByLines[i]);
            if (i != (inputStringByLines.length - 1)) {
                sb.append(System.lineSeparator());
            }
        }
        return sb.toString();
    }

    /**
     * Returns string containing lines with all matched substring replaced
     * @param args String containing command and arguments
     */
    public String replaceAllSubStrings(String args) {
        String oldString = regexInfo[1];
        String newString = regexInfo[2];
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < inputStringByLines.length; i++){
            inputStringByLines[i] = inputStringByLines[i].replaceAll(Pattern.quote(oldString), newString);    
            sb.append(inputStringByLines[i]);
            if (i != (inputStringByLines.length - 1)) {
                sb.append(System.lineSeparator());
            }
        }    
        return sb.toString();
    }

    /**
     * Returns string containing lines when invalid replacement string is
     * provided
     * @param args String containing command and arguments
     */
    public String replaceSubstringWithInvalidReplacement(String args){
        String result = returnOriginalInputStringWhenInvalidRegexReplacement(args);
        return result;
    }

    /**
     * Returns string containing lines when invalid regex is provided
     * @param args String containing command and arguments
     */
    public String replaceSubstringWithInvalidRegex(String args){
        String result = returnOriginalInputStringWhenInvalidRegexReplacement(args);
        return result;
    }

    /**
     * Returns the original input string if regex or replacement is invalid
     * @param args
     * @return
     */
    private String returnOriginalInputStringWhenInvalidRegexReplacement(String args){
        String symbolUsed;
        symbolUsed = Pattern.quote(Character.toString(args.charAt(1)));
        String[] splitArgs = args.split(symbolUsed); 
        return splitArgs[splitArgs.length -1];
    }
}