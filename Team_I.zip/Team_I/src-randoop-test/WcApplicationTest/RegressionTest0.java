import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test01");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        java.lang.String[] str_array9 = new java.lang.String[] { "0", "", "0", "hi!", "hi!", "0" };
        java.io.InputStream inputStream10 = null;
        java.io.OutputStream outputStream11 = null;
        try {
            wcApplication0.run(str_array9, inputStream10, outputStream11);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.WcException");
        } catch (sg.edu.nus.comp.cs4218.exception.WcException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertNotNull(str_array9);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test02");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        int[] i_array1 = null;
        try {
            java.lang.String str3 = wcApplication0.finalCommandInFile(i_array1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test03");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        try {
            java.lang.String str4 = wcApplication0.returnFileContentInFile("1");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.WcException");
        } catch (sg.edu.nus.comp.cs4218.exception.WcException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test04");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        int[] i_array8 = new int[] { (short) 1, 10, (byte) 0, ' ', (byte) 100 };
        java.lang.String str10 = wcApplication0.finalCommandInStdin(i_array8, "1");
        java.lang.String str12 = wcApplication0.printWordCountInFile("hi!");
        java.lang.String[] str_array16 = new java.lang.String[] { "hi!", "1", "" };
        java.io.InputStream inputStream17 = null;
        java.io.OutputStream outputStream18 = null;
        try {
            wcApplication0.run(str_array16, inputStream17, outputStream18);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.WcException");
        } catch (sg.edu.nus.comp.cs4218.exception.WcException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertNotNull(i_array8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 1   " + "'", str10.equals("1 1   "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertNotNull(str_array16);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test05");
        java.io.BufferedReader bufferedReader0 = null;
        try {
            java.lang.String str1 = sg.edu.nus.comp.cs4218.impl.app.WcApplication.getFileContentInStr(bufferedReader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test06");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        java.lang.String[] str_array3 = null;
        try {
            int[] i_array5 = wcApplication0.commandProcessing(str_array3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test07");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        int[] i_array8 = new int[] { (short) 1, 10, (byte) 0, ' ', (byte) 100 };
        java.lang.String str10 = wcApplication0.finalCommandInStdin(i_array8, "1");
        java.lang.String str12 = wcApplication0.printWordCountInFile("hi!");
        java.lang.String[] str_array13 = new java.lang.String[] {};
        java.io.InputStream inputStream14 = null;
        java.io.OutputStream outputStream15 = null;
        try {
            wcApplication0.run(str_array13, inputStream14, outputStream15);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.WcException");
        } catch (sg.edu.nus.comp.cs4218.exception.WcException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertNotNull(i_array8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 1   " + "'", str10.equals("1 1   "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertNotNull(str_array13);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test08");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        int[] i_array8 = new int[] { (short) 1, 10, (byte) 0, ' ', (byte) 100 };
        java.lang.String str10 = wcApplication0.finalCommandInStdin(i_array8, "1");
        java.lang.String str12 = wcApplication0.printWordCountInFile("hi!");
        try {
            java.lang.String str14 = wcApplication0.returnFileContentInFile("1");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.WcException");
        } catch (sg.edu.nus.comp.cs4218.exception.WcException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertNotNull(i_array8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 1   " + "'", str10.equals("1 1   "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test09");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        java.lang.String str4 = wcApplication0.printNewlineCountInFile("1 1   ");
        java.lang.String[] str_array9 = new java.lang.String[] { "0 0 0", "1 1   ", "1 1   ", "1 1   " };
        java.io.InputStream inputStream10 = null;
        java.io.OutputStream outputStream11 = null;
        try {
            wcApplication0.run(str_array9, inputStream10, outputStream11);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.WcException");
        } catch (sg.edu.nus.comp.cs4218.exception.WcException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertNotNull(str_array9);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test10");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printAllCountsInFile("0 0 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5 3 0" + "'", str2.equals("5 3 0"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test11");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInStdin("0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test12");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        java.lang.String str4 = wcApplication0.printNewlineCountInFile("1 1   ");
        java.lang.String str6 = wcApplication0.printAllCountsInStdin("");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication7 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str9 = wcApplication7.printNewlineCountInFile("hi!");
        java.lang.String str11 = wcApplication7.printWordCountInStdin("hi!");
        java.lang.String str13 = wcApplication7.printCharacterCountInFile("0");
        int[] i_array16 = new int[] { (byte) 100, (byte) 1 };
        java.lang.String str18 = wcApplication7.finalCommandInFile(i_array16, "hi!");
        java.lang.String str20 = wcApplication0.finalCommandInFile(i_array16, "hi!");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication21 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str23 = wcApplication21.printNewlineCountInFile("hi!");
        java.lang.String str25 = wcApplication21.printNewlineCountInFile("1 1   ");
        java.lang.String str27 = wcApplication21.printAllCountsInStdin("");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication28 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str30 = wcApplication28.printNewlineCountInFile("hi!");
        java.lang.String str32 = wcApplication28.printWordCountInStdin("hi!");
        java.lang.String str34 = wcApplication28.printCharacterCountInFile("0");
        int[] i_array37 = new int[] { (byte) 100, (byte) 1 };
        java.lang.String str39 = wcApplication28.finalCommandInFile(i_array37, "hi!");
        java.lang.String str41 = wcApplication21.finalCommandInFile(i_array37, "hi!");
        java.lang.String str43 = wcApplication0.finalCommandInStdin(i_array37, "0 0 0");
        try {
            java.lang.String str45 = wcApplication0.returnFileContentInFile("0 0 0");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.WcException");
        } catch (sg.edu.nus.comp.cs4218.exception.WcException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0 0 0" + "'", str6.equals("0 0 0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(i_array16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "3 1 " + "'", str18.equals("3 1 "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "3 1 " + "'", str20.equals("3 1 "));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0 0 0" + "'", str27.equals("0 0 0"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1" + "'", str32.equals("1"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertNotNull(i_array37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "3 1 " + "'", str39.equals("3 1 "));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "3 1 " + "'", str41.equals("3 1 "));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "5 3 " + "'", str43.equals("5 3 "));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test13");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        java.lang.String str4 = wcApplication0.printWordCountInStdin("hi!");
        java.lang.String str6 = wcApplication0.printCharacterCountInFile("0");
        try {
            java.lang.String str8 = wcApplication0.returnFileContentInFile("0");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.WcException");
        } catch (sg.edu.nus.comp.cs4218.exception.WcException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test14");
        sg.edu.nus.comp.cs4218.impl.app.WcApplication wcApplication0 = new sg.edu.nus.comp.cs4218.impl.app.WcApplication();
        java.lang.String str2 = wcApplication0.printNewlineCountInFile("hi!");
        java.lang.String str4 = wcApplication0.printWordCountInStdin("hi!");
        java.lang.String str6 = wcApplication0.printCharacterCountInFile("0");
        java.lang.String[] str_array7 = new java.lang.String[] {};
        java.io.InputStream inputStream8 = null;
        java.io.OutputStream outputStream9 = null;
        try {
            wcApplication0.run(str_array7, inputStream8, outputStream9);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.WcException");
        } catch (sg.edu.nus.comp.cs4218.exception.WcException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertNotNull(str_array7);
    }
}

