package sg.edu.nus.comp.cs4218.app;

import sg.edu.nus.comp.cs4218.Application;

public interface Wc extends Application {

	/**
	 * Returns string containing the character count in file
	 * @param args String of file content
	 */
	public String printCharacterCountInFile(String args);

	/**
	 * Returns string containing the word count in file
	 * @param args String of file content
	 */
	public String printWordCountInFile(String args);

	/**
	 * Returns string containing the newline count in file
	 * @param args String of file content
	 */
	public String printNewlineCountInFile(String args);

	/**
	 * Returns string containing all counts in file
	 * @param args String of file content
	 */
	public String printAllCountsInFile(String args);

	/**
	 * Returns string containing the character count in Stdin
	 * @param args String of file content
	 */
	public String printCharacterCountInStdin(String args);

	/**
	 * Returns string containing the word count in Stdin
	 * @param args String of file content
	 */
	public String printWordCountInStdin(String args);

	/**
	 * Returns string containing the newline count in Stdin
	 * @param args String of file content
	 */
	public String printNewlineCountInStdin(String args);

	/**
	 * Returns string containing all counts in Stdin
	 * @param args String of file content
	 */
	public String printAllCountsInStdin(String args);

}
