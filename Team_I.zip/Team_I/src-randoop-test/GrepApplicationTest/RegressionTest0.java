import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test01");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String[] str_array6 = new java.lang.String[] { "grep: Insufficient Parameters\n", "hi!", "hi!", "hi!", "hi!" };
        java.io.InputStream inputStream7 = null;
        java.io.OutputStream outputStream8 = null;
        try {
            grepApplication0.run(str_array6, inputStream7, outputStream8);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertNotNull(str_array6);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test02");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String str4 = grepApplication0.grepFromStdin("");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication5 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str7 = grepApplication5.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array9 = grepApplication5.decomposeStr("grep: Insufficient Parameters\n");
        java.io.InputStream inputStream10 = null;
        java.io.OutputStream outputStream11 = null;
        try {
            grepApplication0.run(str_array9, inputStream10, outputStream11);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "grep: Insufficient Parameters\n" + "'", str4.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(str_array9);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test03");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array4 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication5 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str7 = grepApplication5.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array9 = grepApplication5.decomposeStr("grep: Insufficient Parameters\n");
        java.io.InputStream inputStream10 = null;
        java.io.OutputStream outputStream11 = null;
        try {
            grepApplication0.run(str_array9, inputStream10, outputStream11);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(str_array4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(str_array9);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test04");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array4 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        java.io.OutputStream outputStream6 = null;
        try {
            grepApplication0.writeToOutputStream("", outputStream6);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(str_array4);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test05");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String str4 = grepApplication0.grepInvalidPatternInFile("grep: Insufficient Parameters\n");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test06");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array4 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        java.lang.String[] str_array8 = new java.lang.String[] { "hi!", "grep: Insufficient Parameters\n", "hi!" };
        java.io.InputStream inputStream9 = null;
        java.io.OutputStream outputStream10 = null;
        try {
            grepApplication0.run(str_array8, inputStream9, outputStream10);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(str_array4);
        org.junit.Assert.assertNotNull(str_array8);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test07");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepFromStdin("");
        java.lang.String str4 = grepApplication0.grepFromMultipleFiles("hi!");
        java.lang.String str6 = grepApplication0.grepInvalidPatternInStdin("hi!");
        try {
            boolean b8 = grepApplication0.checkIfFileIsReadable("grep: Insufficient Parameters\n");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "grep: Insufficient Parameters\n" + "'", str2.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "grep: Insufficient Parameters\n" + "'", str4.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test08");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication3 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str5 = grepApplication3.grepFromStdin("");
        java.lang.String str7 = grepApplication3.grepFromMultipleFiles("hi!");
        java.lang.String[] str_array9 = grepApplication3.decomposeStr("grep: Insufficient Parameters\n");
        java.io.InputStream inputStream10 = null;
        java.io.OutputStream outputStream11 = null;
        try {
            grepApplication0.run(str_array9, inputStream10, outputStream11);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "grep: Insufficient Parameters\n" + "'", str5.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "grep: Insufficient Parameters\n" + "'", str7.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNotNull(str_array9);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test09");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array4 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        java.lang.String str6 = grepApplication0.grepInvalidPatternInStdin("grep: Insufficient Parameters\n");
        try {
            boolean b8 = grepApplication0.checkIfFileIsReadable("");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(str_array4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test10");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String str4 = grepApplication0.grepFromStdin("");
        java.lang.String str6 = grepApplication0.grepInvalidPatternInStdin("");
        java.lang.String str8 = grepApplication0.grepFromMultipleFiles("hi!");
        java.lang.String str10 = grepApplication0.grepFromOneFile("");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "grep: Insufficient Parameters\n" + "'", str4.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "grep: Insufficient Parameters\n" + "'", str8.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "grep: Insufficient Parameters\n" + "'", str10.equals("grep: Insufficient Parameters\n"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test11");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepFromStdin("");
        try {
            boolean b4 = grepApplication0.checkIfFileIsReadable("grep: Insufficient Parameters");
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "grep: Insufficient Parameters\n" + "'", str2.equals("grep: Insufficient Parameters\n"));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test12");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepFromStdin("");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication3 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str5 = grepApplication3.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array7 = grepApplication3.decomposeStr("grep: Insufficient Parameters\n");
        java.lang.String str9 = grepApplication3.grepInvalidPatternInStdin("grep: Insufficient Parameters\n");
        java.lang.String str11 = grepApplication3.grepFromStdin("");
        java.lang.String[] str_array13 = grepApplication3.decomposeStr("hi!");
        java.io.InputStream inputStream14 = null;
        java.io.OutputStream outputStream15 = null;
        try {
            grepApplication0.run(str_array13, inputStream14, outputStream15);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "grep: Insufficient Parameters\n" + "'", str2.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(str_array7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "grep: Insufficient Parameters\n" + "'", str11.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNotNull(str_array13);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test13");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepFromStdin("");
        java.lang.String str4 = grepApplication0.grepFromMultipleFiles("hi!");
        java.lang.String str6 = grepApplication0.grepFromStdin("grep: Insufficient Parameters");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "grep: Insufficient Parameters\n" + "'", str2.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "grep: Insufficient Parameters\n" + "'", str4.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test14");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array4 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        java.lang.String[] str_array6 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        java.lang.String str8 = grepApplication0.grepFromOneFile("grep: Insufficient Parameters\n");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(str_array4);
        org.junit.Assert.assertNotNull(str_array6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "grep: Too many parameters\n" + "'", str8.equals("grep: Too many parameters\n"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test15");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array4 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication5 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str7 = grepApplication5.grepFromStdin("");
        java.lang.String str9 = grepApplication5.grepFromMultipleFiles("hi!");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication10 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str12 = grepApplication10.grepInvalidPatternInStdin("hi!");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication13 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str15 = grepApplication13.grepFromStdin("");
        java.lang.String str17 = grepApplication13.grepFromMultipleFiles("hi!");
        java.lang.String[] str_array19 = grepApplication13.decomposeStr("grep: Insufficient Parameters\n");
        java.lang.String str20 = grepApplication10.composeArgs(str_array19);
        java.lang.String str21 = grepApplication5.composeArgs(str_array19);
        java.lang.String str22 = grepApplication0.composeArgs(str_array19);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(str_array4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "grep: Insufficient Parameters\n" + "'", str7.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "grep: Insufficient Parameters\n" + "'", str9.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "grep: Insufficient Parameters\n" + "'", str15.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "grep: Insufficient Parameters\n" + "'", str17.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNotNull(str_array19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "grep: Insufficient Parameters" + "'", str20.equals("grep: Insufficient Parameters"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "grep: Insufficient Parameters" + "'", str21.equals("grep: Insufficient Parameters"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "grep: Insufficient Parameters" + "'", str22.equals("grep: Insufficient Parameters"));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test16");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepFromStdin("");
        java.lang.String str4 = grepApplication0.grepFromMultipleFiles("hi!");
        java.lang.String[] str_array6 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        java.lang.String str8 = grepApplication0.grepInvalidPatternInStdin("grep: Too many parameters\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "grep: Insufficient Parameters\n" + "'", str2.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "grep: Insufficient Parameters\n" + "'", str4.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNotNull(str_array6);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test17");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.io.OutputStream outputStream4 = null;
        try {
            grepApplication0.writeToOutputStream("", outputStream4);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test18");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String str4 = grepApplication0.grepFromMultipleFiles("hi!");
        java.lang.String str6 = grepApplication0.grepFromMultipleFiles("grep: Too many parameters\n");
        java.lang.String str8 = grepApplication0.grepFromOneFile("grep: Insufficient Parameters");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "grep: Insufficient Parameters\n" + "'", str4.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "grep: Too: No such file or directory \ngrep: many: No such file or directory \ngrep: parameters\n: No such file or directory \n" + "'", str6.equals("grep: Too: No such file or directory \ngrep: many: No such file or directory \ngrep: parameters\n: No such file or directory \n"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "grep: Too many parameters\n" + "'", str8.equals("grep: Too many parameters\n"));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test19");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array4 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        java.lang.String str6 = grepApplication0.grepInvalidPatternInStdin("grep: Insufficient Parameters\n");
        java.lang.String str8 = grepApplication0.grepFromStdin("");
        java.lang.String[] str_array10 = grepApplication0.decomposeStr("hi!");
        java.lang.String str12 = grepApplication0.grepFromOneFile("grep: Insufficient Parameters");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(str_array4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "grep: Insufficient Parameters\n" + "'", str8.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertNotNull(str_array10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "grep: Too many parameters\n" + "'", str12.equals("grep: Too many parameters\n"));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test20");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepFromStdin("");
        java.lang.String str4 = grepApplication0.grepFromMultipleFiles("hi!");
        java.lang.String str6 = grepApplication0.grepFromStdin("hi!");
        java.lang.String str8 = grepApplication0.grepFromStdin("grep: Insufficient Parameters\n");
        java.lang.String[] str_array10 = grepApplication0.decomposeStr("grep: Insufficient Parameters");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "grep: Insufficient Parameters\n" + "'", str2.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "grep: Insufficient Parameters\n" + "'", str4.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "grep: Insufficient Parameters\n" + "'", str6.equals("grep: Insufficient Parameters\n"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(str_array10);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test21");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String[] str_array4 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        java.lang.String[] str_array6 = grepApplication0.decomposeStr("grep: Insufficient Parameters\n");
        java.io.OutputStream outputStream8 = null;
        try {
            grepApplication0.writeToOutputStream("grep: Too many parameters\n", outputStream8);
            org.junit.Assert.fail("Expected exception of type sg.edu.nus.comp.cs4218.exception.GrepException");
        } catch (sg.edu.nus.comp.cs4218.exception.GrepException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(str_array4);
        org.junit.Assert.assertNotNull(str_array6);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test22");
        sg.edu.nus.comp.cs4218.impl.app.GrepApplication grepApplication0 = new sg.edu.nus.comp.cs4218.impl.app.GrepApplication();
        java.lang.String str2 = grepApplication0.grepInvalidPatternInStdin("hi!");
        java.lang.String str4 = grepApplication0.grepFromStdin("grep: Insufficient Parameters\n");
        java.lang.String str6 = grepApplication0.grepInvalidPatternInFile("grep: Insufficient Parameters");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(str6);
    }
}

