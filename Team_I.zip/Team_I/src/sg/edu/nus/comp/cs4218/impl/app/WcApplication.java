package sg.edu.nus.comp.cs4218.impl.app;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.app.Wc;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.InvalidFileOrDirException;
import sg.edu.nus.comp.cs4218.exception.WcException;

import java.io.*;

public class WcApplication implements Wc{

	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws AbstractApplicationException {
		// TODO Auto-generated method stub
		if (args == null) {
			throw new WcException("Null arguments");
	    }

	    if (stdout == null) {
	    	throw new WcException("OutputStream not provided");
	    }

	    BufferedReader reader = null;
        String str = null;
        String result = null;

        // WC does not accept multiple files. The last argument will be considered as a filepath when stdin is null. Other
        // arguments will be considered as options. Does not allow fileNames with spaces
        // Eg: wc
        if(args.length == 0 && stdin == null) {
            throw new WcException("Incomplete command");
        }
        // Eg: wc < test.txt
        else if (args.length == 0 && stdin != null) {
            reader = new BufferedReader(new InputStreamReader(stdin));

            try {
                str = getFileContentInStr(reader);
            } catch (IOException e) {
                throw new WcException("IOException");
            }

            result = printAllCountsInStdin(str);
        }
        // Eg: wc test.txt
        else if (args.length == 1 && args[0].charAt(0) != '-'){
            str = returnFileContentInFile(args[0]);
            result = printAllCountsInFile(str);
        }
        else {
            String lastArg = args[args.length - 1];

            int [] commandArr; // [0] = "-m" [1] = "-w" [2] = "-l"

            if (lastArg.charAt(0) == '-' && stdin == null) {
                throw new WcException("InputStream not provided");
            }
            // Eg: wc -lm < test.txt || wc -l -m test.txt
            else if (lastArg.charAt(0) == '-' && stdin != null) {
                reader = new BufferedReader(new InputStreamReader(stdin));

                try {
                    str = getFileContentInStr(reader);
                } catch (IOException e) {
                    throw new WcException("IOException");
                }
                commandArr = commandProcessing(args, false);
                result = finalCommandInStdin(commandArr, str);
            }

            // wc -l -m test.txt
            else if (lastArg.charAt(0) != '-') {
                str = returnFileContentInFile(lastArg);
                commandArr = commandProcessing(args, true);
                result = finalCommandInFile(commandArr, str);
            }
        }

        try {
            stdout.write(result.getBytes());
            stdout.write(System.getProperty("line.separator").getBytes());
        } catch (IOException e) {
            throw new WcException("IOException");
        }
	}

    /**
     * Returns a string that contents the file content
     * @param file
     * @return
     * @throws WcException
     */
    public String returnFileContentInFile(String file) throws WcException {
        String str;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(
                    Environment.checkFileOrDir(file)));
            str = getFileContentInStr(reader);
        } catch (IOException e) {
            throw new WcException("IOException");
        } catch (InvalidFileOrDirException e) {
            throw new WcException(e.getMessage());
        }
        return str;
    }


    /**
     * Returns an array that contains the count of the type of option given in the command.
     * @param args
     * @param isFile
     * @return
     * @throws WcException
     */
    public int[] commandProcessing(String[] args, boolean isFile) throws WcException {
        int[] commandArr = new int[3];
        int len = isFile ? (args.length - 1) : args.length;

        for (int i = 0; i < len; i++) {
            if (args[i].charAt(0) != '-') {
                throw new WcException("Illegal option");
            }
            for(int j = 1; j < args[i].length(); j++) {
                if(args[i].charAt(j) == 'm') {
                    commandArr[0] += 1;
                } else if (args[i].charAt(j) == 'w') {
                    commandArr[1] += 1;
                } else if (args[i].charAt(j) == 'l') {
                    commandArr[2] += 1;
                } else {
                    throw new WcException("Illegal option " +  args[i].charAt(j));
                }
            }
        }
        return commandArr;
    }

    /**
     * Returns a string that has the final values of the requested options. Calls all relevant
     * function for stdin.
     * @param arr
     * @param str
     * @return
     */
    public String finalCommandInStdin(int[] arr, String str) {
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > 0) {
                if (i == 0) {
                    res.append(printCharacterCountInStdin(str));
                } else if (i == 1) {
                    res.append(printWordCountInStdin(str));
                } else if (i == 2) {
                    res.append(printNewlineCountInStdin(str));
                }
                res.append(" ");
            }
        }

        return res.toString();
    }

    /**
     * Returns a string that has the final values of the requested options. Calls all relevant
     * function for file.
     * @param arr
     * @param str
     * @return
     */
    public String finalCommandInFile(int[] arr, String str) {
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > 0) {
                if (i == 0) {
                    res.append(printCharacterCountInFile(str));
                } else if (i == 1) {
                    res.append(printWordCountInFile(str));
                } else if (i == 2) {
                    res.append(printNewlineCountInFile(str));
                }
                res.append(" ");
            }
        }

        return res.toString();
    }

    /**
     * Converts file content into a string.
     * @param reader
     * @return
     * @throws IOException
     */
	public static String getFileContentInStr(BufferedReader reader)
			throws IOException {
		StringBuilder concatStr = new StringBuilder();

		int currChar;
		while((currChar = reader.read()) != -1) {
			concatStr.append((char) currChar);
		}
			
		reader.close();

		return concatStr.toString();
	}

    /**
     * Counts the number of character in a file. Param accepts only the
     * content of the file in the form of a string
     * @param content
     * @return
     */
	@Override
	public String printCharacterCountInFile(String content) {
		int count = 0;
        for(Character s: content.toCharArray()) {
            count++;
        }
        return Integer.toString(count);

	}

    /**
     * Counts the number of word in a file. Param accepts only the
     * content of the file in the form of a string
     * @param content
     * @return
     */
	@Override
	public String printWordCountInFile(String content) {
		if (content.length() == 0)
			return Integer.toString(0);
		
		int count = 0;
		String[] words = content.trim().split("\\s+");

		for (int i = 0; i < words.length; i++) {
			count += (words[i].length() > 0) ? 1 : 0; 
		}

		return Integer.toString(count);
	}


    /**
     * Counts the number of newlines in a file. Param accepts only the
     * content of the file in the form of a string
     * @param content
     * @return
     */
	@Override
	public String printNewlineCountInFile(String content) {
		int count = 0;
		for (int i = 0; i < content.length(); i++) {
			if (content.charAt(i) == '\n') {
				count++;
			}
		}

		return Integer.toString(count);
	}

    /**
     * Return a string that contains all the count in a file. Param accepts only the
     * content of the file in the form of a string
     * @param content
     * @return
     */
	@Override
	public String printAllCountsInFile(String content) {
        StringBuilder str = new StringBuilder();
        str.append(printCharacterCountInFile(content));
		str.append(" ");
		str.append(printWordCountInFile(content));
		str.append(" ");
        str.append(printNewlineCountInFile(content));

		return str.toString();
	}

    /**
     * Return a string that counts the number of character in a stdin. Param accepts only the
     * content of the file in the form of a string
     * @param content
     * @return
     */
	@Override
	public String printCharacterCountInStdin(String content) {
		return printCharacterCountInFile(content);
	}

    /**
     * Return a string that counts the word in stdin Param accepts only the
     * content of the file in the form of a string
     * @param content
     * @return
     */
	@Override
	public String printWordCountInStdin(String content) {
		return printWordCountInFile(content);
	}

    /**
     * Return a string that counts the number of newlines in stdin. Param accepts only the
     * content of the file in the form of a string
     * @param content
     * @return
     */
	@Override
	public String printNewlineCountInStdin(String content) {
		return printNewlineCountInFile(content);
	}

    /**
     * Return a string that contains all the count in a stdin. Param accepts only the
     * content of the file in the form of a string
     * @param content
     * @return
     */
	@Override
	public String printAllCountsInStdin(String content) {
		return printAllCountsInFile(content);
	}

	
}
