package sg.edu.nus.comp.cs4218.impl.app;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.CdException;
import sg.edu.nus.comp.cs4218.exception.InvalidFileOrDirException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class CdApplication implements Application {
    @Override
    public void run(String[] args, InputStream stdin, OutputStream stdout) throws CdException {
        if (args == null) {
            throw new CdException("Null arguments");
        }

        if (stdout == null) {
            throw new CdException("OutputStream not provided");
        }

        if (args.length == 0) {
            throw new CdException("No directory provided");
        }

        if (args.length > 1) {
            throw new CdException("Invalid directory");
        }

        try {
            Environment.setCurrentDirectory(Environment.currentDirectory, args[0]);
        }  catch (IOException e) {
            throw new CdException("IOException");
        } catch (InvalidFileOrDirException e) {
            throw new CdException(e.getMessage());
        }
    }
}
