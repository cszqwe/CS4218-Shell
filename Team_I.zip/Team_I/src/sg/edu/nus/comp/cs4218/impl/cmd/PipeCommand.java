package sg.edu.nus.comp.cs4218.impl.cmd;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import sg.edu.nus.comp.cs4218.Command;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;

public class PipeCommand implements Command {
	static final Character DOUBLE_QUOTE = '"';
	static final Character SINGLE_QUOTE = '\'';
	static final Character PIPE = '|';

	String cmdline;
	Boolean error;
	String errorMsg;
	private final ArrayList<CallCommand> pipedCommandList;
//	private ArrayList<ExecutableThread> threads;

	public PipeCommand(String cmdline) {
		this.cmdline = cmdline.trim();
		this.pipedCommandList = new ArrayList<CallCommand>();
		error = false;
		errorMsg = "";
	}

	@Override
	public void evaluate(InputStream stdin, OutputStream stdout) throws AbstractApplicationException, ShellException {
		if (error) {
			throw new ShellException(errorMsg);
		}
		String command = "";

		HashMap<String, Integer> tokensMap = new HashMap<String, Integer>();
		tokensMap.put("startDQ", -1);
		tokensMap.put("endDQ", -1);
		tokensMap.put("startSQ", -1);
		tokensMap.put("endSQ", -1);

		boolean hasDoubleQuote = false;
		boolean hasSingleQuote = false;

		for (int i = 0; i < cmdline.length(); i++) {
			if (cmdline.charAt(i) == PIPE) {
				int startDQ = tokensMap.get("startDQ");
				int endDQ = tokensMap.get("endDQ");
				int startSQ = tokensMap.get("startSQ");
				int endSQ = tokensMap.get("endSQ");
				if ((startDQ == -1 && endDQ == -1 && startSQ == -1 && endSQ == -1)
						|| (startDQ != -1 && endDQ != -1 && i > endDQ) || (startSQ != -1 && endSQ != -1 && i > endSQ)) {
//					System.out.println("up" + command);
					this.pipedCommandList.add(new CallCommand(command));
					command = "";
					tokensMap.put("startDQ", -1);
					tokensMap.put("endDQ", -1);
					tokensMap.put("startSQ", -1);
					tokensMap.put("endSQ", -1);
					continue;
				}
			} else if (cmdline.charAt(i) == DOUBLE_QUOTE) {
				if (!hasDoubleQuote) {
					tokensMap.put("startDQ", i);
				} else {
					tokensMap.put("endDQ", i);
				}
				hasDoubleQuote = !hasDoubleQuote;
			} else if (cmdline.charAt(i) == SINGLE_QUOTE) {
				if (!hasSingleQuote) {
					tokensMap.put("startSQ", i);
				} else {
					tokensMap.put("endSQ", i);
				}
				hasSingleQuote = !hasSingleQuote;
			}
			command = command + cmdline.charAt(i);

			if (i + 1 == cmdline.length()) {
				if (!this.pipedCommandList.isEmpty()) {
//					System.out.println("down" + command);

					this.pipedCommandList.add(new CallCommand(command));
				} else {
					CallCommand callCommand = new CallCommand(command);
					callCommand.evaluate(null, stdout);
				}
			}
		}

		try {
//			threads = new ArrayList<ExecutableThread>();

			// Setup streams for each commands
			InputStream currentInput = stdin;
			OutputStream currentOutput;
			ArrayList<InputStream> inputs = new ArrayList<InputStream>();
			ArrayList<OutputStream> outputs = new ArrayList<OutputStream>();
			for (int i = 0; i < pipedCommandList.size(); i++) {
//				CallCommand callCommand = pipedCommandList.get(i);
				if (i == pipedCommandList.size() - 1) {
					currentOutput = stdout;
//					callCommand.setCloseOutput(false);
				} else {
					currentOutput = new PipedOutputStream();
//					callCommand.setCloseOutput(true);
				}
				inputs.add(currentInput);
				outputs.add(currentOutput);
//				ExecutableThread thread = new ExecutableThread(callCommand, currentInput, currentOutput);
//				threads.add(thread);

				if (i < pipedCommandList.size() - 1) {
					currentInput = new PipedInputStream((PipedOutputStream) currentOutput);
				}
			}
			for (int i = 0; i < pipedCommandList.size(); i++) {
				CallCommand callCommand = pipedCommandList.get(i);
				if (i == pipedCommandList.size() - 1) {
					callCommand.setCloseOutput(false);
				} else {
					callCommand.setCloseOutput(true);
				}
				callCommand.evaluate(inputs.get(i), outputs.get(i));
			}
			
//			// Start all commands
//			for (Thread thread : threads) {
//				thread.start();
//				System.out.println("this thread started:" + thread);
//			}
//
//			waitAllThreads();
		} catch (IOException e) {
			throw new ShellException(e.getMessage());
		} finally {
			terminate();
		}

	}

//	private void waitAllThreads() throws ShellException, AbstractApplicationException {
//		Boolean isRunning = true;
//		while (isRunning) {
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				throw new ShellException(e.getMessage());
//			}
//			isRunning = false;
//			for (ExecutableThread thread : threads) {
//				if (thread.isAlive()) {
//					isRunning = true;
//					break;
//				} else if (thread.getShellException() != null) {
//					throw thread.getShellException();
//				} else if (thread.getApplicationException() != null) {
//					throw thread.getApplicationException();
//				}
//			}
//		}
//	}

	@Override
	public void terminate() {
//		if (threads != null) {
//			for (ExecutableThread thread : threads) {
//				thread.interrupt();
//			}
//		}
	}

}
