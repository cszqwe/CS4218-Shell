package sg.edu.nus.comp.cs4218.impl.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.app.Grep;
import sg.edu.nus.comp.cs4218.exception.GrepException;

/**
 * The grep command searches for lines containing a match to a specified
 * pattern. The output of the command is the list of the lines. Each line is
 * printed followed by a newline.
 * 
 * <p>
 * <b>Command format:</b> <code>grep PATTERN [FILE]...</code>
 * <dl>
 * <dt>PATTERN</dt>
 * <dd>specifies a regular expression in JAVA format
 * <dt>FILE</dt>
 * <dd>the name of the file(s). If no files are specified, use stdin.</dd>
 * </dl>
 * </p>
 */

public class GrepApplication implements Grep {
	/**
	 * Runs the grep application with the specified arguments.
	 * 
	 * @param args
	 *            Array of arguments for the application. The first array
	 *            element is the keyword to search for, the rest of the array
	 *            elements are paths to target files. If no files are specified
	 *            stdin is used.
	 * @param stdin
	 *            An InputStream. The input for the command is read from this
	 *            InputStream if no files are specified.
	 * @param stdout
	 *            An OutputStream. The output of the command is written to this
	 *            OutputStream.
	 * 
	 * @throws GrepException
	 *             If the file(s) specified do not exist or are unreadable.
	 */
	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws GrepException {
		if (args == null || args.length == 0) {
			throw new GrepException("Insufficient Parameters");
		} else {
			if (stdout == null) {
				throw new GrepException("Null OutputStream");
			}

			int numOfFiles = args.length - 1;
			String extractedStr = "";
			String keyword = args[0];
			String composedStr = composeArgs(args);

			// for(int i = 0; i < args.length; i++) {
			// System.out.println(i + ": " + args[i]);
			// }
			// System.out.println("stdin: " + stdin);
			// System.out.println("stdout: " + stdout);

			if (numOfFiles == 0) {
				String isPatternValidMsg = grepInvalidPatternInStdin(composedStr);

				if (isPatternValidMsg != null) {
					writeToOutputStream(isPatternValidMsg, stdout);
					return;
				}

				BufferedReader reader;
				String line;
				String[] stdinArgs = new String[2];
				stdinArgs[0] = keyword;

				if (stdin == null) {
					reader = new BufferedReader(new InputStreamReader(System.in));
					try {
						while ((line = reader.readLine()) != null) {
							stdinArgs[1] = line;
							composedStr = composeArgs(stdinArgs);
							extractedStr = grepFromStdin(composedStr);
							writeToOutputStream(extractedStr, stdout);
						}
					} catch (IOException e) {
						throw new GrepException(e.getMessage());
					}
				} else {
					reader = new BufferedReader(new InputStreamReader(stdin));
					try {
						while ((line = reader.readLine()) != null) {
							stdinArgs[1] = line;
							composedStr = composeArgs(stdinArgs);
							extractedStr = extractedStr + grepFromStdin(composedStr);
						}
						writeToOutputStream(extractedStr, stdout);
					} catch (IOException e) {
						throw new GrepException(e.getMessage());
					}
				}
			} else {
				String isPatternValidMsg = grepInvalidPatternInFile(composedStr);
				if (isPatternValidMsg != null) {
					writeToOutputStream(isPatternValidMsg, stdout);
					return;
				}
				if (numOfFiles == 1) {
					extractedStr = grepFromOneFile(composedStr);
					writeToOutputStream(extractedStr, stdout);
				} else {
					extractedStr = grepFromMultipleFiles(composedStr);
					writeToOutputStream(extractedStr, stdout);
				}
			}

		}

	}

	@Override
	public String grepFromStdin(String args) {
		if (args == null) {
			return "grep: Null Arguments" + System.lineSeparator();
		}
		String[] decomposedArgs = decomposeStr(args);

		if (decomposedArgs.length == 1) {
			return "grep: Insufficient Parameters" + System.lineSeparator();
		}

		String inputLine = "";

		Pattern pattern = Pattern.compile(decomposedArgs[0]);

		for (int i = 1; i < decomposedArgs.length; i++) {
			inputLine = inputLine + decomposedArgs[i] + " ";
		}
		inputLine = inputLine.trim();

		Matcher m = pattern.matcher(inputLine);

		if (m.find()) {
			return inputLine + System.lineSeparator();
		}

		return "";
	}

	@Override
	public String grepFromOneFile(String args) {
		if (args == null) {
			return "grep: Null Arguments" + System.lineSeparator();
		}
		String[] decomposedArgs = decomposeStr(args);

		if (decomposedArgs.length == 1) {
			return "grep: Insufficient Parameters" + System.lineSeparator();
		} else if (decomposedArgs.length > 2) {
			return "grep: Too many parameters" + System.lineSeparator();
		}

		try {
			return grep(decomposedArgs);
		} catch (GrepException e) {
			return e.getMessage();
		}
	}

	@Override
	public String grepFromMultipleFiles(String args) {
		if (args == null) {
			return "grep: Null Arguments" + System.lineSeparator();
		}

		String[] decomposedArgs = decomposeStr(args);

		if (decomposedArgs.length < 3) {
			return "grep: Insufficient Parameters" + System.lineSeparator();
		}

		try {
			return grep(decomposedArgs);
		} catch (GrepException e) {
			return e.getMessage();
		}
	}

	@Override
	public String grepInvalidPatternInStdin(String args) {
		if (args == null) {
			return null;
		}
		String[] decomposedArgs = decomposeStr(args);
		return grepInvalidPattern(decomposedArgs[0]);
	}

	@Override
	public String grepInvalidPatternInFile(String args) {
		if (args == null) {
			return null;
		}
		String[] decomposedArgs = decomposeStr(args);
		return grepInvalidPattern(decomposedArgs[0]);
	}

	/**
	 * Grep all lines with pattern matched
	 * 
	 * @param args
	 *            First array element contains pattern, the following array
	 *            elements contain file paths to be matched
	 * @return All lines of pattern matched
	 * @throws GrepException
	 */
	private String grep(String[] args) throws GrepException {
		Pattern pattern = Pattern.compile(args[0]);
		Path filePath;
		Path currentDir = Paths.get(Environment.currentDirectory);
		boolean isFileReadable = false;
		String prefix = "";
		String extractedStr = "";

		for (int i = 1; i < args.length; i++) {
			if (args.length > 2) {
				Path tempPath = Paths.get(args[i]);
				prefix = tempPath.getFileName().toString() + ":";
			}
			filePath = currentDir.resolve(args[i]);

			try {
				isFileReadable = checkIfFileIsReadable(args[i]);
			} catch (GrepException e) {
				extractedStr = extractedStr + e.getMessage();
				continue;
			}

			if (isFileReadable) {
				try {
					byte[] byteFileArray = Files.readAllBytes(filePath);
					String fileStr = new String(byteFileArray);
					String lines[] = fileStr.split("\\r?\\n");

					for (int j = 0; j < lines.length; j++) {
						Matcher matcher = pattern.matcher(lines[j]);
						if (matcher.find()) {
							extractedStr = extractedStr + prefix + lines[j] + System.lineSeparator();
						}
					}
				} catch (IOException e) {
					throw new GrepException("Could not write to output stream");
				}
			}
		}

		return extractedStr;
	}

	/**
	 * Validate the given pattern
	 * 
	 * @param pattern
	 *            Given pattern in string
	 * @return Error message if pattern is invalid, else return null
	 */
	private String grepInvalidPattern(String pattern) {
		try {
			Pattern.compile(pattern);
		} catch (PatternSyntaxException exception) {
			return exception.getMessage();
		}

		return null;
	}

	/**
	 * Write input string to given output stream
	 * 
	 * @param str
	 *            Target string to be output
	 * @param stdout
	 *            Target output stream to be written
	 * @throws GrepException
	 */
	public void writeToOutputStream(String str, OutputStream stdout) throws GrepException {
		if (stdout == null) {
			throw new GrepException("Null output stream");
		}
		try {
			if (str == null) {
				stdout.write(("grep: Null Arguments" + System.lineSeparator()).getBytes());
			} else {
				stdout.write(str.getBytes());
			}
		} catch (IOException e) {
			throw new GrepException("Could not write to output stream");
		}
	}

	/**
	 * Checks if a file is readable.
	 * 
	 * @param filePath
	 *            The path to the file
	 * @return True if the file is readable.
	 * @throws GrepException
	 *             If the file is not readable
	 */
	public boolean checkIfFileIsReadable(String filePathStr) throws GrepException {
		if (filePathStr == null || filePathStr.equals("")) {
			throw new GrepException(filePathStr + ": No such file or directory" + System.lineSeparator());
		}

		Path filePath = Paths.get(filePathStr);

		if (Files.isDirectory(filePath)) {
			String pathStr = filePath.getFileName().toString();
			if (filePathStr.substring(filePathStr.length() - 1).equals("/")) {
				pathStr = pathStr + "/";
			}
			throw new GrepException(pathStr + ": Is a directory" + System.lineSeparator());
		}
		if (Files.exists(filePath) && Files.isReadable(filePath)) {
			return true;
		} else {
			throw new GrepException(filePathStr + ": No such file or directory " + System.lineSeparator());
		}
	}

	/**
	 * Convert array of strings into a string with space delimiter
	 * 
	 * @param args
	 *            Target array to be composed
	 * @return A string composed by all array elements
	 */
	public String composeArgs(String[] args) {
		if (args == null || args.length == 0) {
			return null;
		}

		String composedStr = "";
		for (int i = 0; i < args.length; i++) {
			composedStr = composedStr + args[i] + " ";
		}

		return composedStr.trim();
	}

	/**
	 * Split a string with space delimiter
	 * 
	 * @param composedStr
	 *            Target string to be decomposed
	 * @return An array of strings
	 */
	public String[] decomposeStr(String composedStr) {
		if (composedStr == null) {
			return null;
		}
		return composedStr.split(" ");
	}
}
